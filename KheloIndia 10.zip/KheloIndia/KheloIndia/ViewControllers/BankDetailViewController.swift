//
//  BankDetailViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class BankDetailViewController: UIViewController {
    // IBOutlets
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var bankAccountNumberTextField: UITextField!
    @IBOutlet weak var bankReAccountNumberTextField: UITextField!
    @IBOutlet weak var ifscTextField: UITextField!
    @IBOutlet weak var recipientTextField: UITextField!
    var userId: Int = 0
    var mobileNo: String = ""

    // iVar
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupData()
    }
    
    // MARK: - Private Methods
    private func setupUI() {
        phoneNumberTextField?.text = mobileNo
        phoneNumberTextField.isUserInteractionEnabled = false
        
//        nameTextField?.text = "pawan kumar"
//        phoneNumberTextField?.text = "9663399316"
//        bankAccountNumberTextField?.text = "fd6545645665"
//        bankReAccountNumberTextField?.text = "fd6545645665"
//        ifscTextField?.text = "hdfc43234234"
//        recipientTextField?.text = "pks"
    }
    
    private func setupData() {
        
    }
    
    
    @IBAction func backClicked() {
      self.navigationController?.popViewController(animated: true)
    }
     
    
    //MARK:- IBActions
    @IBAction func submitClicked() {

        let name = nameTextField?.text?.trimmed()
        let phoneNumber = phoneNumberTextField.text?.trimmed()
        let accountNumber = bankAccountNumberTextField?.text?.trimmed()
        let reAccountNumber = bankReAccountNumberTextField.text?.trimmed()
        let ifsc = ifscTextField?.text?.trimmed()
        let recipient = recipientTextField.text?.trimmed()
         
        var errorMessage = ""
        if !(name != nil && (name?.length)! > 0) {
           errorMessage = Constants.ErrorMessages.emptyFullName
        }
        else if !(phoneNumber != nil && (phoneNumber?.length)! > 0) {
            errorMessage = Constants.ErrorMessages.emptyPhone
        }
        else if !((phoneNumber?.isValidPhoneNumber)!) {
            errorMessage = Constants.ErrorMessages.invalidPhone
        }
        else if !(accountNumber != nil && (accountNumber?.length)! > 0) {
           errorMessage = "Please enter account number"
        }
        else if !(reAccountNumber != nil && (reAccountNumber?.length)! > 0) {
           errorMessage = "Please reenter account number"
        }
        else if accountNumber != reAccountNumber {
            errorMessage = "Account number didn't match"
        }
        else if !(ifsc != nil && (ifsc?.length)! > 0) {
           errorMessage = "Please enter IFSC code"
        }
        else if !(ifsc != nil && (ifsc?.length)! > 0) {
           errorMessage = "Please enter IFSC code"
        }
        else if !(recipient != nil && (recipient?.length)! > 0) {
            errorMessage = "Please enter bank name"
        }
        if errorMessage.length > 0 {
           self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: errorMessage)
           return
       }

        self.cdmBankDetails(name: name!, phoneNumber: phoneNumber!, accountNumber: accountNumber!, reAccountNumber: reAccountNumber!, ifsc: ifsc!, recipient: recipient!)
    }
}

extension BankDetailViewController {
    //MARK: - Custom Methods
    private func moveToDashboard() {
        // Move to dashboard
        let name = nameTextField?.text?.trimmed()
        let phoneNumber = phoneNumberTextField.text?.trimmed()
        
        var user = User()
        user.userName = name!
        user.userEmail = phoneNumber!
        user.userId = self.userId
        UserManager.shared.activeUser = user
        AppDefaults.selectedLoginType = .volunteer
        AppDelegate.shared.presentRootViewController()
    }
}

extension BankDetailViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
 


extension BankDetailViewController {
    func cdmBankDetails(name: String, phoneNumber: String,accountNumber: String, reAccountNumber: String,ifsc: String, recipient: String) {

        var params: [String: Any] = [String: Any]()
        params["ProfileMobileNo"] = phoneNumber
        params["ProfileType"] = "Volunteer"
        params["ProfileName"] = name
        params["BankAccNo"] = accountNumber
        params["BankIfscCode"] = ifsc
        params["BankName"] = recipient
        params["DeviceID"] = "MOB123"
        params["DeviceTokken"] = "MOB123"
        params["DeviceOS"] = "iOS"
        
 
        
        SVProgressHUD.show()
        ServiceLayer.requestWithPostData(router: Router.saveVolunter, params) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    //
                    
    if ((responseObject!["status"] as! String) == "200") &&  ((responseObject!["result"]  as? Int == 1)) {                        self.moveToDashboard()
                    }
                    else {
                        self.showAlertViewWithMessage("Error", message: "Please enter valid data.")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)
            }
        }
    }
}

//
//  NewFeedbackVC.swift
//  KheloIndia
//
//  Created by Narender Kumar on 12/14/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class NewFeedbackVC: UIViewController,UITextViewDelegate {
    
    @IBOutlet weak var tbl1: UITableView!
    @IBOutlet weak var tbl2: UITableView!
    @IBOutlet weak var textView: UITextView!
    
    var feedbackArray1:[(name: String, value: Int)] = []
    var feedbackArray2:[(name: String, value: Int)] = []

    var isFromDashboard = false
    @IBOutlet weak var menuButton: UIButton!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        feedbackArray1.append((name: "BreakFast", value: 0))
        feedbackArray1.append((name: "Lunch", value: 0))
        feedbackArray1.append((name: "Snacks", value: 0))
        feedbackArray1.append((name: "Dinner", value: 0))
        
        feedbackArray2.append((name: "Transportation", value: 0))
        feedbackArray2.append((name: "Hotel", value: 0))
        
        tbl1.register(UINib(nibName: "FeedbackCell", bundle: nil), forCellReuseIdentifier: "FeedbackCell")
        tbl2.register(UINib(nibName: "FeedbackCell", bundle: nil), forCellReuseIdentifier: "FeedbackCell")
        //Breakfast, Lunch, Snacks, Dinner ----- Transportation, Hotel
        
        let image = isFromDashboard ? UIImage(named: "backArrowWhite") : UIImage(named: "menu")
        self.menuButton.setImage(image, for: .normal)

        textView.text = "Comments"
        textView.textColor = UIColor.lightGray
        textView.delegate = self
        getData()
    }
    

     //IBAction
      @IBAction func menuButtonClicked() {
          if isFromDashboard {
            navigationController?.popViewController(animated: true)
          } else {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue:
                NotificationName.sideMenuToggle.value), object: nil)
          }
      }
     

    
    //IBAction
        @IBAction func submitButtonClicked() {
            cmdSubmitFeedback()
        }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Comments"
            textView.textColor = UIColor.lightGray
        }
    }
}


extension NewFeedbackVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tbl1 {
            return feedbackArray1.count
        } else {
            return feedbackArray2.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tbl1 {
            let cell = tbl1.dequeueReusableCell(withIdentifier: "FeedbackCell", for: indexPath ) as? FeedbackCell
            cell?.setData(feedbackArray1[indexPath.row])
            cell?.delegate = self
            return cell!
        } else {
            let cell = tbl1.dequeueReusableCell(withIdentifier: "FeedbackCell", for: indexPath ) as? FeedbackCell
            cell?.setData(feedbackArray2[indexPath.row])
            cell?.delegate = self
            return cell!
        }
    }
}

extension NewFeedbackVC: FeedbackCellDelegate {
    
    func didFeedbackTapped(feedback: (name: String, value: Int)) {

        print(feedback)
        
        for (ix,emo) in feedbackArray1.enumerated() {
            if emo.name == feedback.name  {
                feedbackArray1[ix] = feedback
            }
        }
        
        for (ix,emo) in feedbackArray2.enumerated() {
              if emo.name == feedback.name  {
                  feedbackArray2[ix] = feedback
              }
        }
    }
    
}

extension NewFeedbackVC {
    
    func converBoolToInt(data:String)->Int {

        if data == "Average"{
            return 1
        }
         else if data == "Good"{
            return 2
        }
        else if data == "VeryGood"{
            return 3
        }
        else {
            return 0
        }
    }

    
    func parseData( feedback: [String:Any]) {
       
        var isStatusUpdated = false
        if feedback["TeamReachVenue"] as? String == "Y" {
            isStatusUpdated = true
        }
        else if feedback["TeamReachHotel"] as? String == "Y" {
            isStatusUpdated = true
        }
        else if feedback["Breakfast"] as? String == "Y" {
            isStatusUpdated = true
        }else if feedback["Lunch"] as? String == "Y" {
            isStatusUpdated = true
        }else if feedback["Snacks"] as? String == "Y" {
            isStatusUpdated = true
        }else if feedback["Dinner"] as? String == "Y" {
            isStatusUpdated = true
        }
        
        if !isStatusUpdated {
            self.showAlertViewWithMessage("Error", message: "Please update food & travel status before submiting feedback.")
            self.menuButtonClicked()
            return
        }
        
        if let comment = feedback["Comment"] {
            textView.text = comment as? String
            textView.textColor = UIColor.black
        }
     

        feedbackArray1[0].value = self.converBoolToInt(data: (feedback["BreakfastFeedback"] as? String)!)
        feedbackArray1[1].value = self.converBoolToInt(data: (feedback["LunchFeedback"] as? String)!)
        feedbackArray1[2].value = self.converBoolToInt(data: (feedback["SnacksFeedback"] as? String)!)
        feedbackArray1[3].value = self.converBoolToInt(data: (feedback["DinnerFeedback"] as? String)!)
        feedbackArray2[0].value = self.converBoolToInt(data: (feedback["TeamReachVenueFeedback"] as? String)!)
        feedbackArray2[1].value = self.converBoolToInt(data: (feedback["TeamReachHotelFeedback"] as? String)!)

  
        print("feedbackArray1",feedbackArray1)
        print("feedbackArray2",feedbackArray2)

        tbl1.reloadData()
        tbl2.reloadData()
    }
    
    func getData() {
        
        let str = "/\(UserManager.shared.activeUser.userId ?? 0)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.getfeedBack, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    if ((responseObject!["status"] as! String) == "200") {
                        
                        if let feedback = responseObject!["result"]  as? [String:Any]{
                            self.parseData(feedback: feedback)
                        }
                        
                    }
                    else {
                        self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)

            }
        }
    }
    
    private func stateAPI() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getStateList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    print(i)
                    //self.states.append(State.init(json: i)!)
                }
            case .failure:
                print(result)
            }
        }
    }
 
    func cmdSubmitFeedback() {
 
        var params: [String: Any] = [String: Any]()
        params["Cdm_ID"] = UserManager.shared.activeUser.userId
        params["Comment"] = textView.text.trimmed()
 
         for data in feedbackArray1 {
                     
                   if data.value > 0 {
                           var key = "BreakfastFeedback"
                           var value = "VeryGood"

                           if data.name == "BreakFast" {
                            key = "BreakfastFeedback"
                           }
                           else if data.name == "Lunch" {
                            key = "LunchFeedback"
                           }
                           else if data.name == "Snacks" {
                            key = "SnacksFeedback"
                           }
                           else if data.name == "Dinner" {
                            key = "DinnerFeedback"
                           }
                           else if data.name == "Transportation" {
                            key = "TeamReachVenueFeedback"
                           }
                           else if data.name == "Hotel" {
                            key = "TeamReachHotelFeedback"
                           }

                           if data.value == 1{
                           value = "Average"
                           }
                           else if data.value  == 2 {
                           value = "Good"
                           }
                           else if data.value  == 3{
                           value = "VeryGood"
                           }

                           params[key] = value
                      }
                      print(data)
               }
              
        for data in feedbackArray2 {
              
            if data.value > 0 {
                    var key = "BreakfastFeedback"
                    var value = "VeryGood"

                    if data.name == "BreakFast" {
                     key = "BreakfastFeedback"
                    }
                    else if data.name == "Lunch" {
                     key = "LunchFeedback"
                    }
                    else if data.name == "Snacks" {
                     key = "SnacksFeedback"
                    }
                    else if data.name == "Dinner" {
                     key = "DinnerFeedback"
                    }
                    else if data.name == "Transportation" {
                     key = "TeamReachVenueFeedback"
                    }
                    else if data.name == "Hotel" {
                     key = "TeamReachHotelFeedback"
                    }

                    if data.value == 1{
                    value = "Average"
                    }
                    else if data.value  == 2 {
                    value = "Good"
                    }
                    else if data.value  == 3{
                    value = "VeryGood"
                    }

                    params[key] = value
               }
               print(data)
        }
       

        SVProgressHUD.show()
        ServiceLayer.requestWithPostData(router: Router.feedBack, params) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    if ((responseObject!["status"] as! String) == "200") &&  ((((responseObject!["result"]  as? [String:Any]) != nil))) {
                        self.showAlertViewWithMessage(Constants.AlertTitles.successTitle, message: "Feedback submitted successfully.")
                        self.menuButtonClicked()
                    }
                    else {
                        self.showAlertViewWithMessage("Error", message: "Please enter valid data.")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)
            }
        }
    }
}


  

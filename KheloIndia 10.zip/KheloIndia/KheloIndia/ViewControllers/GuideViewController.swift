//
//  GuideViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/15/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class GuideViewController: UIViewController {
    // IBOutlets
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var menuButton: UIButton!
    var isFromDashboard = false
    // iVar
    var functionalArea:[FunctionalArea] = []

    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let image = isFromDashboard ? UIImage(named: "backArrowWhite") : UIImage(named: "menu")
        self.menuButton.setImage(image, for: .normal)
        self.functionalAreaAPI()
    }
        
    //IBAction
    @IBAction func menuButtonClicked() {
        if isFromDashboard {
            navigationController?.popViewController(animated: true)
        } else {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue:
                NotificationName.sideMenuToggle.value), object: nil)
        }
    }
}

extension GuideViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return functionalArea.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //FunctionalAreaCell
        let cell = tblView.dequeueReusableCell(withIdentifier: String(describing: FunctionalAreaCell.self), for: indexPath) as! FunctionalAreaCell
        cell.setData(functionalArea[indexPath.row])
        return cell
    }
}

extension GuideViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //let vc = UIStoryboard.fetchHotelViewController()
        //vc.isFromDashboard = true
        
        let vc = UIStoryboard.fetchResponsibilityViewController()
        vc.isFromDashboard = true
        vc.selectedFunctionalArea = FunctionalArea(AreaID: functionalArea[indexPath.row].AreaID, AreaName: functionalArea[indexPath.row].AreaName)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}


extension GuideViewController {
    
    private func functionalAreaAPI() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getFunctionalAreaList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    print(i)
                    let area = FunctionalArea.init(json: i)
                    self.functionalArea.append(area!)
                }
                if self.functionalArea.count > 0 {
                    self.tblView.reloadData()
                } else {
                    
                }
            case .failure:
                print(result)
            }
        }
    }
}


class FunctionalAreaCell: UITableViewCell {
    
    @IBOutlet weak var title: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    func setData(_ functionalArea: FunctionalArea) {
        self.title.text = functionalArea.AreaName
    }
}



//print(hotel?.HotelAddress)
//if let url = URL(string: "tel://\(hotel?.HotelAddress)"),
//    UIApplication.shared.canOpenURL(url) {
//    UIApplication.shared.open(url, options: [:], completionHandler: nil)
//}

//
//  ContainerViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class ContainerViewController: UIViewController {
    
    @IBOutlet weak var mainContainerView: UIView!
    @IBOutlet weak var sideContainerView: UIView!
    @IBOutlet weak var sideMenuConstraint: NSLayoutConstraint!
    @IBOutlet weak var mainContainerConstraint: NSLayoutConstraint!
    
    var sideMenuOpen = false
    var menuController:MenuViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(toggleSideMenu), name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(showViewController(_:)), name: NSNotification.Name(rawValue: NotificationName.showVC.value), object: nil)
        setupUI()
    }
    
    func setupUI() {
        configureMenuViewController()
        configureDashboardViewController()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func configureMenuViewController() {
        let dashboardController = UIStoryboard.fetchDashboardController()
        //vc.user = user
        mainContainerView.addSubview(dashboardController.view)
        addChild(dashboardController)
        dashboardController.didMove(toParent: self)
    }
    
    private func configureDashboardViewController() {
 
        if menuController == nil {
            menuController = UIStoryboard.fetchMenuViewController()
            menuController.view.frame = sideContainerView.bounds
            sideContainerView.addSubview(menuController.view)
            addChild(menuController)
            menuController.didMove(toParent: self)
        }
    }
    
    @objc func toggleSideMenu() {
        if sideMenuOpen {
            sideMenuConstraint.constant = -275
            mainContainerConstraint.constant = 0
            mainContainerView.alpha = 1.0
            mainContainerView.isUserInteractionEnabled = true
        } else {
            sideMenuConstraint.constant = 0
            mainContainerConstraint.constant = -275
            mainContainerView.alpha = 0.6
            mainContainerView.isUserInteractionEnabled = false
        }
        sideMenuOpen = !sideMenuOpen
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.view.layoutIfNeeded()
        }
    }
    
    @objc func showViewController(_ notification:Notification) {
        toggleSideMenu()
        if let index = notification.userInfo?[NotificationKey.vcIndex.value] as? Int {
            let userType = notification.userInfo?[NotificationKey.userType.value] as? LoginType ?? .none
            switch userType {
            case .cdm:
                cdmViewForIndex(for: index)
            case .player:
                playerViewForIndex(for: index)
            case .volunteer:
                viewForIndex(for: index)
            case .none:
                break
            }
        }
    }

    func playerViewForIndex(for index: Int) {
        var vc: UIViewController?
        switch index {
            case 0:
                vc = moveToDashboardViewController()
            case 1:
                vc = moveToVenueViewController()
            case 2:
                vc = moveToHotelsViewController()
            case 3:
                vc = moveToAboutsViewController()
            case 4:
                vc = moveToResultsViewController()
            case 5:
                vc = moveToContactsViewController()
            case 6:
                 handleLogout()
            default:
                break
        }
        if let target = vc {
            targetVC(vc: target)
        }
    }
    
    func cdmViewForIndex(for index: Int) {
        var vc: UIViewController?
        switch index {
            case 0:
                vc = moveToDashboardViewController()
            case 1:
                vc = moveToVenueViewController()
            case 2:
                vc = moveToHotelsViewController()
            case 3:
                vc = moveToAboutsViewController()
            case 4:
                vc = moveToResultsViewController()
            case 5:
                vc = moveToContactsViewController()
            case 6:
                vc = moveToNewFeedbackViewController()
            case 7:
                 handleLogout()
            default:
                break
        }
        if let target = vc {
            targetVC(vc: target)
        }
    }
    
    func viewForIndex(for index: Int) {
        var vc: UIViewController?
        switch index {
            case 0:
                vc = moveToDashboardViewController()
            case 1:
                vc = moveToAttendanceViewController()
            case 2:
                vc = moveToKitViewController()
           case 3:
                vc = moveToResultsViewController()
           case 4:
                vc = moveToVenueViewController()
            case 5:
                vc = moveToAboutsViewController()
            case 6:
                vc = moveToGuideViewController()
            case 7:
                handleLogout()
            default:
                break
        }
        if let target = vc {
            targetVC(vc: target)
        }
    }
    
    func targetVC(vc: UIViewController) {
        removeMainViewController()
        addChild(vc)
        mainContainerView.addSubview(vc.view)
        vc.view.frame = mainContainerView.bounds
        vc.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        vc.didMove(toParent: self)
    }
    
    func removeMainViewController() {
        if self.children.count > 0 {
            let viewControllers:[UIViewController] = self.children
            for viewContoller in viewControllers {
                if !(viewContoller is MenuViewController) {
                    viewContoller.willMove(toParent: nil)
                    viewContoller.view.removeFromSuperview()
                    viewContoller.removeFromParent()
                }
            }
        }
    }
}

extension ContainerViewController {
    //MARK: -  ViewController Traverse
    func moveToSportsViewController() -> UIViewController {
        return UIStoryboard.fetchSportViewController()
    }

    func moveToDashboardViewController() -> UIViewController {
        return UIStoryboard.fetchDashboardController()
    }
    
    func moveToHotelsViewController() -> UIViewController {
        return UIStoryboard.fetchHotelViewController()
    }
    
    func moveToVenueViewController() -> UIViewController {
        return UIStoryboard.fetchVenueViewController()
    }
    
    func moveToResultsViewController() -> UIViewController {
        return UIStoryboard.fetchResultsViewController()
    }
   
    func moveToContactsViewController() -> UIViewController {
        return UIStoryboard.fetchContactsViewController()
    }
    
    func moveToAboutsViewController() -> UIViewController {
        return UIStoryboard.fetchAboutViewController()
    }
    
    func moveToNewFeedbackViewController() -> UIViewController {
        return UIStoryboard.fetchNewFeedbackViewController()
    }
    
    func moveToAttendanceViewController() -> UIViewController {
        return UIStoryboard.fetchAttendanceViewController()
    }
    
    func moveToKitViewController() -> UIViewController {
        return UIStoryboard.fetchKitViewController()
    }
    
    func moveToGuideViewController() -> UIViewController {
        return UIStoryboard.fetchGuideViewController()
    }
    
    func moveToResponsibilityController() -> UIViewController {
        return UIStoryboard.fetchResponsibilityViewController()
    }
    
    func handleLogout()  {
        
//        showAlertViewWithMessageAndDicisionHandler(Constants.AlertTitles.logoutTitle, message: Constants.AlertTitleMessages.confirmationTitleMessage, trueButtonText: "Yes", falseButtonText: "No", trueActionHandler: {
//                              AppDefaults.selectedLoginType = .none
//                                     UserManager.shared.deleteActiveUser()
//                                     AppDelegate.shared.presentRootViewController()
//                          }, falseActionHandler: {
//                              // nothing to do here
//                   })
        AppDefaults.selectedLoginType = .none
        UserManager.shared.deleteActiveUser()
        AppDelegate.shared.presentRootViewController()
     }
}

 

//
//  UserSelectionViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 11/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class UserSelectionViewController: UIViewController {

    
    @IBOutlet weak var btnPlayer: UIButton!
    @IBOutlet weak var btnVolunteer: UIButton!
    @IBOutlet weak var btnCDM: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        btnPlayer.isSelected = true
        
        
    }
    
    @IBAction func menuPlayerClicked() {
        btnPlayer.isSelected = true
        btnVolunteer.isSelected = false
        btnCDM.isSelected = false

    }
    
    @IBAction func menuVolunteerClicked() {
        btnPlayer.isSelected = false
        btnVolunteer.isSelected = true
        btnCDM.isSelected = false
     }
    
    @IBAction func menuCDMClicked() {
        btnPlayer.isSelected = false
        btnVolunteer.isSelected = false
        btnCDM.isSelected = true
     }

    
    @IBAction func processClicked() {
          
        if btnPlayer.isSelected {
            let viewController = UIStoryboard.fetchPlayerLoginViewController()
            self.navigationController?.pushViewController(viewController, animated: true)

        }
        else if btnVolunteer.isSelected {
            let viewController = UIStoryboard.fetchVolunteerLoginViewController()
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        else {
             let viewController = UIStoryboard.fetchCDMLoginViewController()
             self.navigationController?.pushViewController(viewController, animated: true)
            
        }
       
    }
}
 

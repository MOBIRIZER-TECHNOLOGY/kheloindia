//
//  NewDummyVC.swift
//  KheloIndia
//
//  Created by Narender Kumar on 12/14/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class NewDummyVC: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    private var hotels: [Hotel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(UINib(nibName: "HotelCell", bundle: nil), forCellReuseIdentifier: "HotelCell")
        self.hotelAPI()
    }
    
    private func hotelAPI() {
        SVProgressHUD.show()
           ServiceLayer.request(router: Router.getHotelList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    self.hotels.append( Hotel.init(json: i)!)
                }
                self.tblView.reloadData()
            case .failure:
                print(result)
            }
           }
       }
    

}

extension NewDummyVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hotels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: String(describing: HotelCell.self), for: indexPath) as! HotelCell
        cell.setHotelData(self.hotels[indexPath.row])
        cell.delagate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 175.0
    }
    
}

extension NewDummyVC: HotelCellDelegate {
    
    func didTappedCommon(isNavigation: Bool, isCall: Bool, hotel: Hotel?) {
        if isNavigation {
            // hotel?.GeoLocation
        } else if isCall {
            //hotel?.HotelAddress
        }
    }
}

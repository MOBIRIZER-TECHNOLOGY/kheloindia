//
//  TravelModel.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/15/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import Foundation

class TravelModel {
    var title:String?
    var isCompleted:Bool = false
    
    init(title:String?, isCompleted:Bool = false) {
        self.title = title
        self.isCompleted = isCompleted
    }
}

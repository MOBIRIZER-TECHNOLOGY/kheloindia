//
//  TravelAndFoodViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/14/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class TravelAndFoodViewController: UIViewController {
    
    enum TabSelectionType {
        case travel
        case food
    }
    
    //IBOutlets
    @IBOutlet var tabBarButtons:[UIButton]!
    @IBOutlet weak var dataStackView: UIStackView!
    @IBOutlet weak var headerView: UIView!

    var feedback:[String:Any]? = nil
    
    //iVar
    var selectionType:TabSelectionType = .travel
    var travelData = [
        TravelModel(title:"Team reached Match Venue"),
        TravelModel(title:"Team reached Hotel after match"),
    ]
    
    var foodData = [
        TravelModel(title:"Team had Breakfast"),
        TravelModel(title:"Team had Lunch"),
        TravelModel(title:"Team had Snaks"),
        TravelModel(title:"Team had Dinner"),
    ]

    var isFromDashboard = false
    @IBOutlet weak var menuButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        let image = isFromDashboard ? UIImage(named: "backArrowWhite") : UIImage(named: "menu")
        self.menuButton.setImage(image, for: .normal)
        getData()
    }

    //IBAction
    @IBAction func menuButtonClicked() {
        if isFromDashboard {
          navigationController?.popViewController(animated: true)
        } else {
          NotificationCenter.default.post(name: NSNotification.Name(rawValue:
              NotificationName.sideMenuToggle.value), object: nil)
        }
    }
  
    
    //MARK: - Custom Method
    func setupUI() {
        //shadow setup
        configuretabSelection(tag: selectionType == .travel ? 100 : 101)
        headerView.dropShadow()
    }
    
    func refreshScreen() {
        resetScreen()
        switch selectionType {
            case .travel:
                loadTravelData()
            case .food:
                loadFoodData()
        }
    }
    
    func loadTravelData() {
        var count = 0
        for data in travelData {
            let travelView = FoodView.createFoodView(title: data.title, status: data.isCompleted, index: count) { [unowned self](index, status) in
                self.travelData[index].isCompleted = status
                print("data.title",data.title)
                var key = "TeamReachHotel"
                var value = status ? "Y": "N"
                if data.title == "Team reached Match Venue" {
                     key = "TeamReachVenue"
                }
                self.cmdUpdateFeedback(CdmFeedback: key, Status: value)
            }
            dataStackView.addArrangedSubview(travelView)
            count += 1
        }
    }
    
 
    func loadFoodData() {
        var count = 0
        for data in foodData {
            let foodView = FoodView.createFoodView(title: data.title, status: data.isCompleted, index: count) { [unowned self](index, status) in
                self.foodData[index].isCompleted = status
                print("data.title",data.title)
                var key = "Breakfast"
                var value = status ? "Y": "N"
                if data.title == "Team had Breakfast" {
                     key = "Breakfast"
                }
                else if data.title == "Team had Lunch"{
                    key = "Lunch"
                }
                else if data.title == "Team had Snaks"{
                    key = "Snacks"
                }
                else if data.title == "Team had Dinner"{
                    key = "Dinner"
                }
                self.cmdUpdateFeedback(CdmFeedback: key, Status: value)
            }
            dataStackView.addArrangedSubview(foodView)
            count += 1
        }
    }
    
    func resetScreen() {
        for view in dataStackView.subviews {
            view.removeFromSuperview()
        }
    }
    
    func configuretabSelection(tag:Int) {
        selectionType = tag == 100 ? .travel : .food
        for tabButton in tabBarButtons {
            if tabButton.tag == tag {
                tabButton.superview?.backgroundColor = UIColor(red: 237/255, green: 113/255, blue: 44/255, alpha: 1)
                tabButton.isSelected = true
            } else {
                tabButton.superview?.backgroundColor = .white
                tabButton.isSelected = false
            }
        }
        refreshScreen()
    }

    //MARK: - IBActions
    @IBAction func tabSelectionAction(button: UIButton) {
        if button.isSelected {
            return
        }
        configuretabSelection(tag: button.tag)
    }
}



extension TravelAndFoodViewController {

    
    func parseData() {
       
        self.travelData[0].isCompleted = self.feedback?["TeamReachVenue"] as? String == "Y"
        self.travelData[1].isCompleted = self.feedback?["TeamReachHotel"] as? String == "Y"
        self.foodData[0].isCompleted = self.feedback?["Breakfast"] as? String == "Y"
        self.foodData[1].isCompleted = self.feedback?["Lunch"] as? String == "Y"
        self.foodData[2].isCompleted = self.feedback?["Snacks"] as? String == "Y"
        self.foodData[3].isCompleted = self.feedback?["Dinner"] as? String == "Y"
        refreshScreen()
    }
 
    func cmdUpdateFeedback(CdmFeedback:String,Status:String) {
        
           let str = "/\(CdmFeedback)/\(Status)/\((UserManager.shared.activeUser.userId ?? 0))"

           SVProgressHUD.show()
           ServiceLayer.requestWithData(router: Router.foodTravelStatus, str) { (result: Result<Data
               , Error>) in
               SVProgressHUD.dismiss()
               switch result {
               case .success(let resultData):
                   do {
                       let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                       print(responseObject ?? "")
                       
                       if ((responseObject!["status"] as! String) == "200") &&  ((responseObject!["result"]  as? Int == 1)) {
                         
                       }
                       else {
                           self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                       }
                   } catch {
                       let str = String(decoding: resultData, as: UTF8.self)
                       print("error: \(str)")
                       self.showAlertViewWithMessage("Error", message: str)
                   }
               case .failure( let error):
                   print(error.localizedDescription)
                   self.showAlertViewWithMessage("Error",message: error.localizedDescription)

               }
           }
       }
    
    
    func getData() {
        
        let str = "/\(UserManager.shared.activeUser.userId ?? 0)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.getfeedBack, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    if ((responseObject!["status"] as! String) == "200") {
                        
                        if let feedback = responseObject!["result"]  as? [String:Any]{
                            self.feedback = feedback
                            self.parseData()
                        }
                        
                    }
                   else {
                        self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)

            }
        }
    }
}





 

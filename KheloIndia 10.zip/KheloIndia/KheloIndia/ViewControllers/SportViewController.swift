//
//  SportViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 12/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class SportViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    var sports:[Sport] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.sportAPI()
    }
    
          //IBAction
    @IBAction func menuButtonClicked() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: nil)
    }
}



extension SportViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sports.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SportCell", for: indexPath) as! SportCell
        //cell.delegate = self
        cell.setData(sports[indexPath.row])
        return cell
    }
}



extension SportViewController {
    
    private func sportAPI() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getSportsList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    print(i)
                    let venu = Sport.init(json: i)
                    self.sports.append(venu!)
                }
                if self.sports.count > 0 {
                    self.tblView.reloadData()
                } else {
                    
                }
            case .failure:
                print(result)
            }
        }
    }
}

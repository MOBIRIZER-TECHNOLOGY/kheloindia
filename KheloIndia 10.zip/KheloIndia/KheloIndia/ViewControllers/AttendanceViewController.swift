//
//  AttendanceViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 11/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class AttendanceViewController: UIViewController {

    @IBOutlet weak var inOutTimeView: UIImageView!
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var tapForAttendanceLabel: UILabel!
    
    @IBOutlet weak var inLabel: UILabel!
    @IBOutlet weak var outLabel: UILabel!

    var isFromDashboard = false
    var status = 0
    
    @IBOutlet weak var menuButton: UIButton!

       override func viewDidLoad() {
           super.viewDidLoad()
            //UserManager.shared.activeUser.userId = 4

           let currentDateTime = Date()
           let dateFormatter = DateFormatter()
           dateFormatter.dateStyle = .medium
           dateLabel.text = "\(dateFormatter.string(from: currentDateTime))"
         
            let image = isFromDashboard ? UIImage(named: "backArrowWhite") : UIImage(named: "menu")
            self.menuButton.setImage(image, for: .normal)
            
            let inTimeTapGesture = UITapGestureRecognizer(target: self, action: #selector(AttendanceViewController.inOutTimeviewTapped(_:)))
            inTimeTapGesture.numberOfTapsRequired = 1
            inTimeTapGesture.numberOfTouchesRequired = 1
            inOutTimeView.addGestureRecognizer(inTimeTapGesture)
            inOutTimeView.isUserInteractionEnabled = true
            getData()
       }
        
        @objc func inOutTimeviewTapped(_ sender: UITapGestureRecognizer) {
            print("inTimeviewTapped")
            if status == 3 {
                return
            }
            cmdAttandance()
        }
 
             //IBAction
       @IBAction func menuButtonClicked() {
           if isFromDashboard {
               navigationController?.popViewController(animated: true)
           } else {
               NotificationCenter.default.post(name: NSNotification.Name(rawValue:
                   NotificationName.sideMenuToggle.value), object: nil)
           }
       }
}


extension AttendanceViewController {
     
    func parseData( feedback: [String:Any]) {
       
        var isSignIn = false

        let inTime = feedback["InTime"] as? String
        let outTime = feedback["OutTime"] as? String

        if inTime != "-" {
            isSignIn = true
        }
        else if outTime != "-"{
            isSignIn = true
        }

        if !isSignIn {
            inLabel.text = "--:--"
            outLabel.text = "--:--"
            status = 1
        }
        else if inTime == outTime {
            inLabel.text = inTime
            outLabel.text = "--:--"
            status = 2
        }
        else {
            inLabel.text = inTime
            outLabel.text = outTime
            status = 3
            tapForAttendanceLabel.text = ""
            inOutTimeView.image = UIImage(named: "attandance_1")
        }
 
    }
    
    func getData() {
        let str = "/\(UserManager.shared.activeUser.userId ?? 0)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.getAttendance, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    if ((responseObject!["status"] as! String) == "200") {
 
                        if let feedback = responseObject!["result"]  as? [[String:Any]]{
                            self.parseData(feedback: feedback[0])
                        }
                    }
                   else {
                        self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)

            }
        }
    }
    
     
    
    //kheloindia.dnanetworks.in/appdata/Attendance/1/4583,145899
    func cmdAttandance() {
           
              var lat = "28"
              var lon = "77"
              let str = "/\((UserManager.shared.activeUser.userId ?? 0))/\(lat),\(lon)"

              SVProgressHUD.show()
              ServiceLayer.requestWithData(router: Router.setAttendance, str) { (result: Result<Data
                  , Error>) in
                  SVProgressHUD.dismiss()
                  switch result {
                  case .success(let resultData):
                      do {
                          let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                          print(responseObject ?? "")
                          
                          if ((responseObject!["status"] as! String) == "200")  {
                            
                            if let feedback = responseObject!["result"]  as? [[String:Any]]{
                                self.parseData(feedback: feedback[0])
                            }
                          }
                          else {
                              self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                          }
                      } catch {
                          let str = String(decoding: resultData, as: UTF8.self)
                          print("error: \(str)")
                          self.showAlertViewWithMessage("Error", message: str)
                      }
                  case .failure( let error):
                      print(error.localizedDescription)
                      self.showAlertViewWithMessage("Error",message: error.localizedDescription)

                  }
              }
    }
       
    
}
     

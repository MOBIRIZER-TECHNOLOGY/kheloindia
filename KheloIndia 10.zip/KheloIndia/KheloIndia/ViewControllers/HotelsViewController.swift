//
//  HotelsViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 11/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class UserModel {
    var name = ""
    var lastName = ""
    var des = ""
}

class HotelsViewController: UIViewController , UITableViewDataSource, UITableViewDelegate {
 
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var menuButton: UIButton!
    
    var hotels:[Hotel] = []
    var isFromDashboard = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupData()
    }
    
    func setupUI() {
        let image = isFromDashboard ? UIImage(named: "backArrowWhite") : UIImage(named: "menu")
        self.menuButton.setImage(image, for: .normal)
        tblView.register(UINib(nibName: "HotelCell", bundle: nil), forCellReuseIdentifier: "HotelCell")
    }
    
    func setupData() {
        self.getHotelList()
    }

     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return hotels.count
       }
       
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: String(describing: HotelCell.self), for: indexPath) as! HotelCell
        cell.setHotelData(self.hotels[indexPath.row])
        cell.delagate = self
        return cell
    }
 
        //IBAction
    @IBAction func menuButtonClicked() {
        if isFromDashboard {
            navigationController?.popViewController(animated: true)
        } else {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue:
                NotificationName.sideMenuToggle.value), object: nil)
        }
    }
    
}


extension HotelsViewController: HotelCellDelegate {
    
    func didTappedCommon(isNavigation: Bool, isCall: Bool, hotel: Hotel?) {
        if isNavigation {
            
        if UIApplication.shared.canOpenURL(URL(string:"comgooglemaps://")!) {
            UIApplication.shared.open(URL(string:"comgooglemaps://?center=\(hotel!.GeoLocation)&zoom=14&views=traffic&q=\(hotel!.GeoLocation)")!, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.open(URL(string: "http://maps.google.com/maps?q=loc:\(hotel!.GeoLocation)&zoom=14&views=traffic&q=\(hotel!.GeoLocation)")!, options: [:], completionHandler: nil)
        }
 
            
        } else if isCall {
            //hotel?.HotelAddress
            print(hotel?.HotelAddress)
            if let url = URL(string: "tel://\(hotel?.HotelAddress)"),
                UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
            
        }
    }
}


extension HotelsViewController {
    
    private func getHotelList() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getHotelList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    self.hotels.append( Hotel.init(json: i)! )
                }
                if self.hotels.count > 0 {
                    self.tblView.reloadData()
                } else {
                    
                }
            case .failure:
                print(result)
            }
        }
    }
    
}

extension HotelsViewController: CustomCellDelegate {
    
    func didButtonTapped(_ isDirection: Bool, hotel: Hotel?) {
        if let _ = hotel {
            if isDirection {
                //GoTo direction
                if let url = URL(string: "http://maps.apple.com/?ll=\(String(describing: hotel?.GeoLocation))") {
                     if UIApplication.shared.canOpenURL(url) {
                         UIApplication.shared.open(url, options: [:]
                , completionHandler: nil)
                     }
                 }
            } else {
                //Call
            }
        }
    }
    
}










         
//            // hotel?.GeoLocation
//            if let url = URL(string: "http://maps.apple.com/?ll=\(hotel!.GeoLocation)") {
//                 if UIApplication.shared.canOpenURL(url) {
//                     UIApplication.shared.open(url, options: [:]
//            , completionHandler: nil)
//                 }
//             }

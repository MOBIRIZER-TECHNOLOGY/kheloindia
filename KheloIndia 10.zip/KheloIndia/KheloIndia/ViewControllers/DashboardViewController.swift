//
//  DashboardViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/11/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SideMenu

class DashboardViewController: UIViewController {
    
    // iVar
    var user: User = UserManager.shared.activeUser

    @IBOutlet var label1: UILabel!
    @IBOutlet var label2: UILabel!
    @IBOutlet var label3: UILabel!
    
    @IBOutlet var imageView1: UIImageView!
    @IBOutlet var imageView2: UIImageView!
    @IBOutlet var imageView3: UIImageView!

    @IBOutlet var view1: UIView!
    @IBOutlet var view2: UIView!
    @IBOutlet var view3: UIView!


    //@IBOutlet var btn: [ButtonWithImage]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1. create a gesture recognizer (tap gesture)
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(handleTap1(sender:)))
        // 2. add the gesture recognizer to a view
        view1.addGestureRecognizer(tapGesture1)
        
        // 1. create a gesture recognizer (tap gesture)
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(handleTap2(sender:)))
        // 2. add the gesture recognizer to a view
        view2.addGestureRecognizer(tapGesture2)
        
        // 1. create a gesture recognizer (tap gesture)
        let tapGesture3 = UITapGestureRecognizer(target: self, action: #selector(handleTap3(sender:)))
        // 2. add the gesture recognizer to a view
        view3.addGestureRecognizer(tapGesture3)
        
        // Do any additional setup after loading the view.
        switch AppDefaults.selectedLoginType {
        case .cdm:
           setupSDMUI()
        case .player:
           setupPlayerUI()
        case .volunteer:
            setupVolunteerUI()
        case .none: break
        }
    }
     
    // 3. this method is called when a tap is recognized
    @objc func handleTap1(sender: UITapGestureRecognizer) {
        print("tap 1")
        self.btnAction(label1.text!)
    }
    
    // 3. this method is called when a tap is recognized
    @objc func handleTap2(sender: UITapGestureRecognizer) {
        print("tap 2")
        self.btnAction(label2.text!)
    }
    
    
    // 3. this method is called when a tap is recognized
    @objc func handleTap3(sender: UITapGestureRecognizer) {
        print("tap 3")
        self.btnAction(label3.text!)
    }
    
    
    func setupPlayerUI() {
       
         label1.text = "SCHEDULE"
         imageView1.image = UIImage(named: "kh-11")

        label2.text = "HOTEL"
        imageView2.image = UIImage(named: "kh-10")
        
        
        label3.text = "MATCH VENUE"
        imageView3.image = UIImage(named: "khel")
    }
 
  func setupVolunteerUI() {
        
        label1.text = "ATTENDANCE"
        imageView1.image = UIImage(named: "attendance")

        label2.text = "SCHEDULE"
        imageView2.image = UIImage(named: "kh-11")

        label3.text = "MATCH VENUE"
        imageView3.image = UIImage(named: "khel")
             
    }
    
    
    
    func setupSDMUI() {
      
       label1.text = "UPDATES"
       imageView1.image = UIImage(named: "updates")

 
        label2.text = "FEEDBACK"
        imageView2.image = UIImage(named: "feedback")

   
        label3.text = "MATCH VENUE"
        imageView3.image = UIImage(named: "khel")
        
    }
    

    
    @IBAction func menuButtonClicked() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: nil)
    }
 
    func btnAction(_ titleText: String) {
        
        if titleText == "SCHEDULE" {
            let vc = UIStoryboard.fetchResultsViewController()
            vc.isFromDashboard = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if titleText == "HOTEL" {
            let vc = UIStoryboard.fetchHotelViewController()
            vc.isFromDashboard = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if titleText == "MATCH VENUE" {
            let vc = UIStoryboard.fetchVenueViewController()
            vc.isFromDashboard = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if titleText == "ATTENDANCE" {
            let vc = UIStoryboard.fetchAttendanceViewController()
            vc.isFromDashboard = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if titleText == "UPDATES" {
            let vc = UIStoryboard.fetchTravelAndFoodViewController()
              vc.isFromDashboard = true
              self.navigationController?.pushViewController(vc, animated: true)
        }
        else if titleText == "FEEDBACK" {
             let vc = UIStoryboard.fetchNewFeedbackViewController()
             vc.isFromDashboard = true
             self.navigationController?.pushViewController(vc, animated: true)
        }

    }
}





























 
//
//
//class ButtonWithImage: UIButton {
//    override func layoutSubviews() {
//        super.layoutSubviews()
//        //self.currentBackgroundImage
//        if imageView != nil {
//            imageEdgeInsets = UIEdgeInsets(top: 5, left: (bounds.width - 75), bottom: 5, right: 15)
//            titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: (imageView?.frame.width)! - 75)
//
//        }
//    }
//}
//
//extension DashboardViewController {
//
//
//}
//
//
//
//
//
//
//
//
//
////
////
////func setupUI() {
////    btn.forEach {
////        if $0.tag == 11 {
////            $0.setImage(UIImage(named: "kh-11"), for: .normal)
////        } else if $0.tag == 12 {
////            $0.setImage(UIImage(named: "kh-10"), for: .normal)
////        } else if $0.tag == 13 {
////            $0.setImage(UIImage(named: "khel"), for: .normal)
////        }
////    }
////}
//
//
////@IBAction func btnAction(_ sender: ButtonWithImage) {
////
////    if sender.tag == 11 {
////        let vc = UIStoryboard.fetchResultsViewController()
////        vc.isFromDashboard = true
////        self.navigationController?.pushViewController(vc, animated: true)
////    } else if sender.tag == 12 {
////        let vc = UIStoryboard.fetchHotelViewController()
////        vc.isFromDashboard = true
////        self.navigationController?.pushViewController(vc, animated: true)
////    } else if sender.tag == 13 {
////        let vc = UIStoryboard.fetchVenueViewController()
////        vc.isFromDashboard = true
////        self.navigationController?.pushViewController(vc, animated: true)
////    }
////}
//
//
//
//
//
//enum ButtonEdgeInsetsStyle {
//    // 图片相对于label的位置
//    case Top
//    case Left
//    case Right
//    case Bottom
//}
//
//extension UIButton {
//
//    func layoutButton(style: ButtonEdgeInsetsStyle, imageTitleSpace: CGFloat) {
//        //得到imageView和titleLabel的宽高
//        let imageWidth = self.imageView?.frame.size.width
//        let imageHeight = self.imageView?.frame.size.height
//
//        var labelWidth: CGFloat! = 0.0
//        var labelHeight: CGFloat! = 0.0
//
//        labelWidth = self.titleLabel?.intrinsicContentSize.width
//        labelHeight = self.titleLabel?.intrinsicContentSize.height
//
//        //初始化imageEdgeInsets和labelEdgeInsets
//        var imageEdgeInsets = UIEdgeInsets.zero
//        var labelEdgeInsets = UIEdgeInsets.zero
//
//        //根据style和space得到imageEdgeInsets和labelEdgeInsets的值
//        switch style {
//        /**
//            * titleEdgeInsets是titleLabel相对于其上下左右的inset，跟tableView的contentInset是类似的；
//            * 如果只有title，那titleLabel的 上下左右 都是 相对于Button 的；
//            * 如果只有image，那imageView的 上下左右 都是 相对于Button 的；
//            * 如果同时有image和label，那image的 上下左 是 相对于Button 的，右 是 相对于label 的；
//            * label的 上下右 是 相对于Button的， 左 是 相对于label 的。
//             */
//        case .Top:
//            //上 左 下 右
//            imageEdgeInsets = UIEdgeInsets(top: -labelHeight-imageTitleSpace/2, left: 0, bottom: 0, right: -labelWidth)
//            labelEdgeInsets = UIEdgeInsets(top: 0, left: -imageWidth!, bottom: -imageHeight!-imageTitleSpace/2, right: 0)
//            break;
//
//        case .Left:
//            imageEdgeInsets = UIEdgeInsets(top: 0, left: -imageTitleSpace/2, bottom: 0, right: imageTitleSpace)
//            labelEdgeInsets = UIEdgeInsets(top: 0, left: imageTitleSpace/2, bottom: 0, right: -imageTitleSpace/2)
//            break;
//
//        case .Bottom:
//            imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: -labelHeight!-imageTitleSpace/2, right: -labelWidth)
//            labelEdgeInsets = UIEdgeInsets(top: -imageHeight!-imageTitleSpace/2, left: -imageWidth!, bottom: 0, right: 0)
//            break;
//
//        case .Right:
//            imageEdgeInsets = UIEdgeInsets(top: 0, left: labelWidth+imageTitleSpace/2, bottom: 0, right: -labelWidth-imageTitleSpace/2)
//            labelEdgeInsets = UIEdgeInsets(top: 0, left: -imageWidth!-imageTitleSpace/2, bottom: 0, right: imageWidth!+imageTitleSpace/2)
//            break;
//        }
//
//        self.titleEdgeInsets = labelEdgeInsets
//        self.imageEdgeInsets = imageEdgeInsets
//
//    }
//}
//





//
//
// func setupPlayerUI() {
//         btn.forEach {
//             if $0.tag == 11 {
//                 $0.setImage(UIImage(named: "kh-11"), for: .normal)
//                 $0.setTitle("SCHEDULE", for: .normal)
//
//             } else if $0.tag == 12 {
//                 $0.setTitle("HOTEL", for: .normal)
//                 $0.setImage(UIImage(named: "kh-10"), for: .normal)
//
//             } else if $0.tag == 13 {
//                 $0.setTitle("MATCH VENUE", for: .normal)
//                 $0.setImage(UIImage(named: "khel"), for: .normal)
//             }
//
//            $0.layoutButton(style: ButtonEdgeInsetsStyle.Right, imageTitleSpace: 20)
//         }
//     }
//
//  func setupVolunteerUI() {
//        btn.forEach {
//            if $0.tag == 11 {
//                $0.setTitle("ATTENDANCE", for: .normal)
//                $0.setImage(UIImage(named: "attendance"), for: .normal)
//            } else if $0.tag == 12 {
//                $0.setTitle("SCHEDULE", for: .normal)
//                $0.setImage(UIImage(named: "kh-11"), for: .normal)
//            } else if $0.tag == 13 {
//                $0.setTitle("MATCH VENUE", for: .normal)
//                $0.setImage(UIImage(named: "khel"), for: .normal)
//
//            }
//
//        }
//    }
//
//
//
//    func setupSDMUI() {
//        btn.forEach {
//            if $0.tag == 11 {
//                $0.setTitle("UPDATES", for: .normal)
//                $0.setImage(UIImage(named: "updates"), for: .normal)
//
//            } else if $0.tag == 12 {
//                $0.setTitle("FEEDBACK", for: .normal)
//                $0.setImage(UIImage(named: "feedback"), for: .normal)
//
//            } else if $0.tag == 13 {
//                $0.setTitle("MATCH VENUE", for: .normal)
//                $0.setImage(UIImage(named: "khel"), for: .normal)
//            }
//         }
//    }
//
//
//
//    @IBAction func menuButtonClicked() {
//        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: nil)
//    }
//
//    @IBAction func btnAction(_ sender: ButtonWithImage) {
//
//        let titleText = sender.titleLabel?.text
//        if titleText == "SCHEDULE" {
//            let vc = UIStoryboard.fetchResultsViewController()
//            vc.isFromDashboard = true
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
//        else if titleText == "HOTEL" {
//            let vc = UIStoryboard.fetchHotelViewController()
//            vc.isFromDashboard = true
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
//        else if titleText == "MATCH VENUE" {
//            let vc = UIStoryboard.fetchVenueViewController()
//            vc.isFromDashboard = true
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
//        else if titleText == "ATTENDANCE" {
//            let vc = UIStoryboard.fetchAttendanceViewController()
//            vc.isFromDashboard = true
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
//        else if titleText == "UPDATES" {
//            let vc = UIStoryboard.fetchTravelAndFoodViewController()
//              vc.isFromDashboard = true
//              self.navigationController?.pushViewController(vc, animated: true)
//        }
//        else if titleText == "FEEDBACK" {
//             let vc = UIStoryboard.fetchNewFeedbackViewController()
//             vc.isFromDashboard = true
//             self.navigationController?.pushViewController(vc, animated: true)
//        }
//
//    }
//}

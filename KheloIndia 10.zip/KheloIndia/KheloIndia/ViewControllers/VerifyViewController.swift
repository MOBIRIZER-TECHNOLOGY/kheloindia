//
//  VerifyViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 12/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class VerifyViewController: UIViewController {

    @IBOutlet weak var phoneTxtFld: UITextField!
    @IBOutlet weak var otpTxtFld: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func verifyAction(_ sender: Any) {
        self.verifyPhoneApi(phoneTxtFld.text ?? "", otp: otpTxtFld.text ?? "")
    }
    
    
}


extension VerifyViewController {
    
    private func verifyPhoneApi(_ phone: String, otp: String) {
        
        let str = "/\(phone)/\(otp)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.getVenueList, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                print(responseObject ?? "")
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                }
            case .failure( let error):
                print(error.localizedDescription)
                
            }
        }
    }
    
    
    
        
}

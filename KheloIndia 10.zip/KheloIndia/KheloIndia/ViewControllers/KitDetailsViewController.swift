//
//  KitDetailsViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 13/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class KitDetailsViewController: UIViewController {
    
    @IBOutlet weak var submitKit1Button: UIButton!
    @IBOutlet weak var submitKit2Button: UIButton!

    @IBOutlet weak var msgLabel: UILabel!

    // IBOutlets
    @IBOutlet var receivedKit1Buttons:[UIButton]!
    @IBOutlet var receivedKit2Buttons:[UIButton]!
    
    // iVar
    private var isYesSelectedKit1:Bool = false
    private var isYesSelectedKit2:Bool = false
    
    // iVar
    private var kit1Status:String = "N"
    private var kit2Status:String = "N"
    

    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        getData()
    }
    
    //MARK: - Private Methods
    private func setupUI() {
        kit1Selection(1)
        kit2Selection(1)
    }
    
    //MARK: - IBActions
    @IBAction func confirmClicked(button: UIButton) {
        if button.tag == 100 {
            if kit1Status == "Y" {
                return
            }
            self.cmdKit1Attandance(command: isYesSelectedKit1 ? "Y" : "N")
        } else {
            if kit2Status == "Y" {
                return
            }
            self.cmdKit2Attandance(command: isYesSelectedKit1 ? "Y" : "N")
        }
    }
    
    @IBAction func menuButtonClicked() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: nil)
    }
    
    @IBAction func kit1Click(_ button: UIButton) {
        
        isYesSelectedKit1 = button.tag == 1

         for btn in receivedKit1Buttons {
             if btn == button {
                 btn.isSelected = true
             } else {
                 btn.isSelected = false
             }
         }
     }
     
     @IBAction func kit2Click(_ button: UIButton) {
        
        isYesSelectedKit2 = button.tag == 1

         for btn in receivedKit2Buttons {
             if  button == btn {
                 btn.isSelected = true
             } else {
                 btn.isSelected = false
             }
         }
     }
    
    func kit1Selection(_ tag:Int) {
        for button in receivedKit1Buttons {
            if button.tag == tag {
                button.isSelected = true
                isYesSelectedKit1 = true
            } else {
                button.isSelected = false
            }
        }
    }
    
    func kit2Selection(_ tag:Int) {
        for button in receivedKit2Buttons {
            if button.tag == tag {
                button.isSelected = true
                isYesSelectedKit2 = true
            } else {
                button.isSelected = false
            }
        }
    }
}

 
extension KitDetailsViewController {
     
    func parseData( feedback: [String:Any]) {
        
        kit1Status = (feedback["Kit1"] as? String)!
        kit2Status = (feedback["Kit2"] as? String)!

        if kit1Status == "N" {
            submitKit1Button.isEnabled = true
            
            kit1Selection(0)
        }
        else {
            _ = feedback["Kit1Datetime"] as? String
            submitKit1Button.setBackgroundImage(UIImage(named: "tickButtonBG"), for: .normal)
            submitKit1Button.setTitle("", for: .normal)
            submitKit1Button.backgroundColor = UIColor.clear
            kit1Selection(1)
//            for button in receivedKit1Buttons {
//                button.isEnabled = false
//            }
        }
        
        if kit2Status == "N"{
            
            kit2Selection(0)
        }
        else {
            _ = feedback["Kit2Datetime"] as? String
            submitKit2Button.setBackgroundImage(UIImage(named: "tickButtonBG"), for: .normal)
            submitKit2Button.setTitle("", for: .normal)
            submitKit2Button.backgroundColor = UIColor.clear
            kit2Selection(1)
            
//            for button in receivedKit2Buttons {
//                button.isEnabled = false
//            }

        }

 
    }
    
    func getData() {
        let str = "/\(UserManager.shared.activeUser.userId ?? 0)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.kitlist, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    if ((responseObject!["status"] as! String) == "200") {
                        if let feedback = responseObject!["result"]  as? [[String:Any]]{
                            self.parseData(feedback: feedback[0])
                        }
                    }
                   else {
                        self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)

            }
        }
    }
    
     
    
    //kheloindia.dnanetworks.in/appdata/Attendance/1/4583,145899
    func cmdKit1Attandance(command:String) {
           
              let str = "/\((UserManager.shared.activeUser.userId ?? 0))/\(command)"
              SVProgressHUD.show()
              ServiceLayer.requestWithData(router: Router.kit1, str) { (result: Result<Data
                  , Error>) in
                  SVProgressHUD.dismiss()
                  switch result {
                  case .success(let resultData):
                      do {
                          let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                          print(responseObject ?? "")
                          
                          if ((responseObject!["status"] as! String) == "200") &&  ((responseObject!["result"]  as? Int == 1)) {
                            if command == "Y" {
                                self.submitKit1Button.setBackgroundImage(UIImage(named: "tickButtonBG"), for: .normal)
                                self.submitKit1Button.setTitle("", for: .normal)
                                self.submitKit1Button.backgroundColor = UIColor.clear
                                for button in self.receivedKit1Buttons {
                                    button.isEnabled = false
                                }
                            }
                          }
                          else {
                              self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                              self.kit1Selection(0)

                          }
                      } catch {
                          let str = String(decoding: resultData, as: UTF8.self)
                          print("error: \(str)")
                          self.showAlertViewWithMessage("Error", message: str)
                          self.kit1Selection(0)

                      }
                  case .failure( let error):
                      print(error.localizedDescription)
                      self.showAlertViewWithMessage("Error",message: error.localizedDescription)
                      self.kit1Selection(0)
                  }
              }
      }
    
    
    func cmdKit2Attandance(command:String) {
         
            let str = "/\((UserManager.shared.activeUser.userId ?? 0))/\(command)"
            SVProgressHUD.show()
            ServiceLayer.requestWithData(router: Router.kit2, str) { (result: Result<Data
                , Error>) in
                SVProgressHUD.dismiss()
                switch result {
                case .success(let resultData):
                    do {
                        let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                        print(responseObject ?? "")
                        
                        if ((responseObject!["status"] as! String) == "200") &&  ((responseObject!["result"]  as? Int == 1)) {
                          if command == "Y" {
                              self.submitKit2Button.setBackgroundImage(UIImage(named: "tickButtonBG"), for: .normal)
                              self.submitKit2Button.setTitle("", for: .normal)
                              self.submitKit2Button.backgroundColor = UIColor.clear
                            for button in self.receivedKit2Buttons {
                                button.isEnabled = false
                            }
                          }
                        }
                        else {
                            self.showAlertViewWithMessage("Error", message: "Unable to connect with server.")
                            self.kit2Selection(0)

                        }
                    } catch {
                        let str = String(decoding: resultData, as: UTF8.self)
                        print("error: \(str)")
                        self.showAlertViewWithMessage("Error", message: str)
                        self.kit2Selection(0)

                    }
                case .failure( let error):
                    print(error.localizedDescription)
                    self.showAlertViewWithMessage("Error",message: error.localizedDescription)
                    self.kit2Selection(0)


                }
            }
    }
       
    
}
     

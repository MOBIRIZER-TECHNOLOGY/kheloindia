//
//  LoginCDMViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 11/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class LoginCDMViewController: UIViewController {
    
    @IBOutlet weak var emailTxtFld: UITextField!
    @IBOutlet weak var pwdTxtFld: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        emailTxtFld.text = "anand@gmail.com"
//        emailTxtFld.text = "bikram@gmail.com"
//        emailTxtFld.text = "ajay@gmail.com"
//        emailTxtFld.text = "sanjay@gmail.com"
//        emailTxtFld.text = "tushar@gmail.com"
//        emailTxtFld.text = "rajan@gmail.com"
//        pwdTxtFld.text = "1234"
    }
  
        
    private func moveToNext(userId:Int,userName:String,userEmail:String) {
        var user = User()
        user.userName = userName
        user.userEmail = userEmail
        user.userId = userId
        UserManager.shared.activeUser = user
        AppDefaults.selectedLoginType = .cdm
        AppDelegate.shared.presentRootViewController()
    }
    
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
//    else if !((email?.isValidEmail())!) {
//        errorMessage = Constants.ErrorMessages.invalidEmail
//    }
    
     //MARK:- IBActions
    @IBAction func verifyClicked() {

        let email = emailTxtFld?.text?.trimmed()
        let pwd = pwdTxtFld.text?.trimmed()
        var errorMessage = ""
          if !(email != nil && (email?.length)! > 0) {
              errorMessage = Constants.ErrorMessages.emptyUserName
          }
           else if !((pwd?.isValidPassword())!) {
               errorMessage = Constants.ErrorMessages.invalidPassword
           }
       
          if errorMessage.length > 0 {
              self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: errorMessage)
              return
          }
        
       
       if let email = emailTxtFld.text, !email.isEmpty, let pwd = pwdTxtFld.text, !pwd.isEmpty {
           self.cdmLogin(email, pws: pwd)
       }
      
    }
    
    @IBAction func backClicked() {
      self.navigationController?.popViewController(animated: true)
    }
}


extension LoginCDMViewController {
    
    func cdmLogin(_ email: String, pws: String) {
        let str = "/\(email)/\(pws)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.cdmLogin, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    if ((responseObject!["status"] as! String) == "200") &&  (((responseObject!["result"]  as? [String:Any]) != nil)) {
                        
                        if let player = responseObject!["result"]  as? [String:Any], let userId = player["CdmID"]  as? Int, let userName = player["CdmName"] as? String , let userEmail = player["CdmEmailID"] as? String{
                            self.moveToNext(userId: userId, userName: userName , userEmail: userEmail )
                        }
                    }
                    else if ((responseObject!["status"] as! String) == "200")  {
                        self.showAlertViewWithMessage("Error", message: "Please enter valid user name and password.")
                    }
                    else {
                        self.showAlertViewWithMessage("Error", message: "Unable to login")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)
            }
        }
    }
}

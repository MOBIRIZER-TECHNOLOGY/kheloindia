//
//  OTPViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import OTPTextField
import SVProgressHUD

class OTPViewController: UIViewController {
    // IBOutlets
    @IBOutlet weak var otpTextField: OTPTextField!
    var phone: String = ""
    var otp: String = ""
    var userId: Int = 0
    // iVar
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        //otpTextField.text = "0000"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    
    @IBAction func backClicked() {
      self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- IBActions
    @IBAction func verifyClicked() {
        if let newOtp = otpTextField.text, !newOtp.isEmpty {
 
            if newOtp == otp {
                self.moveToBankDetailScreen()
            } else {
                self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: "OTP not match")
            }
        }
        else {
            self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: "Please enter OTP.")
        }
    }
}

extension OTPViewController {
    //MARK: - Custom Methods
    private func moveToBankDetailScreen() {
        let vc = UIStoryboard.fetchBankDetailViewController()
        vc.userId = self.userId
        vc.mobileNo = phone
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension OTPViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}


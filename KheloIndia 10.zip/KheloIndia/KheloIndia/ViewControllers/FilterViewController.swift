//
//  FilterViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 31/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD
  
protocol FilterCellDelegate:class {
    func didButtonTapped(_ selectedDate:String?, selectedVenu:Venue?,selectedSport:Sport?)
}
  
class FilterViewController: UIViewController {

        @IBOutlet weak var dateBtn: UIButton!
        @IBOutlet weak var venuBtn: UIButton!
        @IBOutlet weak var sportBtn: UIButton!

        private var toolBar = UIToolbar()
        private var picker  = UIPickerView()
    
        private var toolBar1 = UIToolbar()
        private var picker1  = UIPickerView()
    
    
        private var toolBar2 = UIToolbar()
        private var picker2  = UIPickerView()
        
        private var date:[String] = ["ALL","2020-01-09","2020-01-10","2020-01-11","2020-01-12","2020-01-13","2020-01-14","2020-01-15","2020-01-16","2020-01-17","2020-01-18","2020-01-19","2020-01-20","2020-01-21","2020-01-22"]
    
        private var venu:[Venue] = []
        private var sport:[Sport] = []
    
        private var selectedDate:String? = nil
        private var selectedVenu:Venue? = nil
        private var selectedSport:Sport? = nil
        
        weak var delegate: FilterCellDelegate?

        //MARK: - Life Cycle
        override func viewDidLoad() {
            super.viewDidLoad()
            
            self.dateBtn.setTitleColor(.darkGray, for: .normal)
            self.venuBtn.setTitleColor(.darkGray, for: .normal)
            self.sportBtn.setTitleColor(.darkGray, for: .normal)
            
            self.venuAPI()
            let seconds = 0.2
            DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                self.sportAPI()
            }
        }
        
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            self.navigationController?.isNavigationBarHidden = true
        }
     
        @IBAction func backClicked() {
            self.navigationController?.popViewController(animated: true)
        }
    
        @IBAction func dateAction(_ sender: UIButton) {
            if date.count > 0 {
                picker = UIPickerView.init()
                picker.tag = 1
                picker.delegate = self
                picker.dataSource = self
                picker.backgroundColor = UIColor.white
                picker.setValue(UIColor.black, forKey: "textColor")
                picker.autoresizingMask = .flexibleWidth
                picker.contentMode = .center
                picker.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
                self.view.addSubview(picker)
                picker.reloadAllComponents()

                toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
                toolBar.barStyle = .default
                toolBar.items = [UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped))]
                self.view.addSubview(toolBar)
            }
        }
        
          @objc func onDoneButtonTapped() {
               toolBar.removeFromSuperview()
               picker.removeFromSuperview()
           }
    
        @IBAction func venuAction(_ sender: UIButton) {
            
            if venu.count > 0 {
                picker2 = UIPickerView.init()
                picker2.tag = 1
                picker2.delegate = self
                picker2.dataSource = self
                picker2.backgroundColor = UIColor.white
                picker2.setValue(UIColor.black, forKey: "textColor")
                picker2.autoresizingMask = .flexibleWidth
                picker2.contentMode = .center
                picker2.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
                self.view.addSubview(picker2)
                picker2.reloadAllComponents()

                toolBar2 = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
                toolBar2.barStyle = .default
                toolBar2.items = [UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped2))]
                self.view.addSubview(toolBar2)
            } else {
                self.venuAPI()
            }
        }
        
        @objc func onDoneButtonTapped2() {
            toolBar2.removeFromSuperview()
            picker2.removeFromSuperview()
        }
        
        @IBAction func sportAction(_ sender: UIButton) {
            if self.sport.count > 0 {
                picker1 = UIPickerView.init()
                picker1.tag = 1
                picker1.delegate = self
                picker1.dataSource = self
                picker1.backgroundColor = UIColor.white
                picker1.setValue(UIColor.black, forKey: "textColor")
                picker1.autoresizingMask = .flexibleWidth
                picker1.contentMode = .center
                picker1.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
                self.view.addSubview(picker1)
                
                picker1.reloadAllComponents()
                
                toolBar1 = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
                toolBar1.barStyle = .default
                toolBar1.items = [UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped1))]
                self.view.addSubview(toolBar1)
            }
            else {
                self.sportAPI()
            }
        }
        
        @objc func onDoneButtonTapped1() {
            toolBar1.removeFromSuperview()
            picker1.removeFromSuperview()
        }
        
        @IBAction func verifyClicked() {
            self.delegate?.didButtonTapped(self.selectedDate, selectedVenu: self.selectedVenu, selectedSport: self.selectedSport)
            self.navigationController?.popViewController(animated: true)

        }
    }





extension FilterViewController: UIPickerViewDelegate, UIPickerViewDataSource {
        
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
            1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            if pickerView == picker {
                return date.count
            }
            else if pickerView == picker2 {
                return venu.count
            } else {
                return sport.count
            }
        }

        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
                if pickerView == picker {
                    return date[row]
                }
                else if pickerView == picker2 {
                    return venu[row].VenueName
                } else {
                    return sport[row].SportsName
                }
        }

        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            
            if pickerView == picker {
 
                self.selectedDate = date[row]
                self.dateBtn.setTitle(date[row], for: .normal)
                self.dateBtn.setTitleColor(.black, for: .normal)
            }
            else if pickerView == picker2 {
                 
                 self.selectedVenu = venu[row]
                 self.venuBtn.setTitle(venu[row].VenueName, for: .normal)
                 self.venuBtn.setTitleColor(.black, for: .normal)

            } else {
               
                self.selectedSport = sport[row]
                self.sportBtn.setTitle(sport[row].SportsName, for: .normal)
                self.sportBtn.setTitleColor(.black, for: .normal)
            }
  
        }
    }




    extension FilterViewController {
        
        private func venuAPI() {
            SVProgressHUD.show()
            ServiceLayer.request(router: Router.getVenueList, nil) { (result: Result<[[String:AnyObject]], Error>) in
                SVProgressHUD.dismiss()
                switch result {
                case .success (let data):
                    for i in data {
                        print(i)
                        if i != nil {
                            self.venu.append(Venue.init(json: i)!)
                        }
                    }
                case .failure:
                    print(result)
                }
            }
        }
        
        private func sportAPI() {
            SVProgressHUD.show()
            ServiceLayer.request(router: Router.getSportsList, nil) { (result: Result<[[String:AnyObject]], Error>) in
                SVProgressHUD.dismiss()
                switch result {
                case .success (let data):
                    for i in data {
                        print(i)
                        self.sport.append(Sport.init(json: i)!)
                    }
                case .failure:
                    print(result)
                }
            }
        }
        
    }



//
//  SportCell.swift
//  KheloIndia
//
//  Created by pawan singh on 12/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class SportCell: UITableViewCell {
    
    @IBOutlet weak var title: UILabel!
    private var sport: Sport? = nil

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    func setData(_ sport: Sport) {
        self.title.text = sport.SportsName
    }
}

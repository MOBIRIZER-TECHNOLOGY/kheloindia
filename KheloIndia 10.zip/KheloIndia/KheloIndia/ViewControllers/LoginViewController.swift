//
//  LoginViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    // IBOutlets
    @IBOutlet weak var userTypeSegment: UISegmentedControl!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    // iVar
    var buttonName:String = "Login" {
        didSet {
            self.loginButton.setTitleForAll(title: buttonName)
        }
    }

    var userType: UserType = .player
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    // MARK: - Private Methods
    private func refreshUI() {
        switch userType {
        case .player, .manager:
            self.emailTextField.isHidden = false
            self.passwordTextField.isHidden = false
            self.mobileTextField.isHidden = true
            self.mobileTextField.text = nil
            self.buttonName = "Login"
        case .volunteer:
            self.emailTextField.isHidden = true
            self.passwordTextField.isHidden = true
            self.mobileTextField.isHidden = false
            self.emailTextField.text = nil
            self.passwordTextField.text = nil
            self.buttonName = "Send OTP"
        }
    }
    
    //MARK:- IBActions
    @IBAction func loginClicked() {
        switch userType {
        case .player, .manager:
            moveToPreferenceScreen()
        case .volunteer:
            moveToOTPScreen()
        }
    }
    
    @IBAction func userTypeSelected(sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            userType = .player
        case 1:
            userType = .manager
        case 2:
            userType = .volunteer
        default:
            userType = .player
            break
        }
        refreshUI()
    }
}

extension LoginViewController {
    //MARK: - Custom Methods
    private func moveToOTPScreen() {
        let vc = UIStoryboard.fetchOTPViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private func moveToPreferenceScreen() {
        let vc = UIStoryboard.fetchPreferenceViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}


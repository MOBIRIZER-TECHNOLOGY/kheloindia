//
//  LoginVolunteerViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 11/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class LoginVolunteerViewController: UIViewController {
    @IBOutlet weak var phonTxtFld: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
//        phonTxtFld.text = "7838538724"
////        phonTxtFld.text = "9663399316"
        //phonTxtFld.text = "8802346983"
//       phonTxtFld.text = "9663399319"
     // phonTxtFld.text = "9663399318"
     }
     
     @IBAction func backClicked() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func sendOtpClicked() {

        if let phone = phonTxtFld.text, !phone.isEmpty {
            var otp = "\(Int.random(in: 1111..<9999))"
            //otp = "0000"
            self.volunteerLogin(phone, otp: otp)
        }
        else {
            self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: "Please enter phone number.")
        }
    }
}


extension LoginVolunteerViewController {
    private func volunteerLogin(_ pho: String, otp: String) {
        let str = "/\(pho)/\(otp)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.volunteerLogin, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    if ((responseObject!["status"] as! String) == "200") {
                        
                        if (responseObject?["result"] as? [String:Any]) != nil {
                           
                            if let result = responseObject?["result"] as? [String:AnyObject] {
                                let viewController = UIStoryboard.fetchOTPViewController()
                              viewController.phone = pho
                              viewController.otp = otp
                              viewController.userId = result["ProfileID"] as! Int
                              print("OTP : \(viewController.otp)")
                              self.navigationController?.pushViewController(viewController, animated: true)
                            }
              
                        }
                        else {
                            self.showAlertViewWithMessage("Error", message: responseObject?["message"] as! String)
                        }
                        
                    } else {
                        
                        let alert = UIAlertController(title: "Error", message: "Unable to verify OTP", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)
            }
        }
    }
}


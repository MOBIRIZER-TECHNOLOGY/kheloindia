//
//  VenueViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 12/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class VenueViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var menuButton: UIButton!
    var venus:[Venue] = []
    var isFromDashboard = false

    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(UINib(nibName: "NewVenueCell", bundle: nil), forCellReuseIdentifier: "NewVenueCell")
        let image = isFromDashboard ? UIImage(named: "backArrowWhite") : UIImage(named: "menu")
        self.menuButton.setImage(image, for: .normal)
        self.venueAPI()
    }
    
          //IBAction
    @IBAction func menuButtonClicked() {
        if isFromDashboard {
            navigationController?.popViewController(animated: true)
        } else {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue:
                NotificationName.sideMenuToggle.value), object: nil)
        }
    }

}

extension VenueViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return venus.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: String(describing: NewVenueCell.self), for: indexPath) as! NewVenueCell
        cell.setVenueData(self.venus[indexPath.row])
        cell.locationDelagate = self
        return cell
    }
}
  
extension VenueViewController: NewVenueCellDelegate {
    func didVenueTapped(venue: Venue?) {
        print("didVenueTapped",venue!.GeoLocation)
        
        if UIApplication.shared.canOpenURL(URL(string:"comgooglemaps://")!) {
            UIApplication.shared.open(URL(string:"comgooglemaps://?center=\(venue!.GeoLocation)&zoom=14&views=traffic&q=\(venue!.GeoLocation)")!, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.open(URL(string: "http://maps.google.com/maps?q=loc:\(venue!.GeoLocation)&zoom=14&views=traffic&q=\(venue!.GeoLocation)")!, options: [:], completionHandler: nil)
        }

    }
}

extension VenueViewController {

private func venueAPI() {
    SVProgressHUD.show()
    ServiceLayer.request(router: Router.getVenueList, nil) { (result: Result<[[String:AnyObject]], Error>) in
        SVProgressHUD.dismiss()
        switch result {
        case .success (let data):
            for i in data {
                print(i)
                let venu = Venue.init(json: i)
                self.venus.append(venu!)
            }
            if self.venus.count > 0 {
                self.tblView.reloadData()
            } else {
                
            }
        case .failure:
            print(result)
        }
    }
}
}





        

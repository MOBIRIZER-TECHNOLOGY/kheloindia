//
//  CustomCell.swift
//  TableView
//
//  Created by Narender Kumar on 7/21/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import UIKit

protocol CustomCellDelegate:class {
    func didButtonTapped(_ isDirection: Bool, hotel: Hotel?)
}

class CustomCell: UITableViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var desc: UILabel!
    private var hotel: Hotel? = nil
    weak var delegate: CustomCellDelegate?
 
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(_ hotel: Hotel) {
        self.hotel = hotel
        self.title.text = hotel.HotelName
        self.desc.text = hotel.HotelAddress
    }
    
    @IBAction func phoneTapped(_ sender: UIButton) {
        delegate?.didButtonTapped(false, hotel: self.hotel)
    }
    
    @IBAction func directorTapped(_ sender: UIButton) {
        delegate?.didButtonTapped(true, hotel: self.hotel)
    }
    

}

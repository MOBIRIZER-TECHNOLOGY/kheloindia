//
//  PreferenceViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class PreferenceViewController: UIViewController {
    
    @IBOutlet weak var stateBtn: UIButton!
    @IBOutlet weak var sportBtn: UIButton!
    private var toolBar = UIToolbar()
    private var picker  = UIPickerView()
    private var toolBar1 = UIToolbar()
    private var picker1  = UIPickerView()
    private var states:[State] = []
    private var sport:[Sport] = []
    private var selectedState:State? = nil
    private var selectedSport:Sport? = nil
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        self.stateAPI()
        let seconds = 0.2
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            self.sportAPI()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    // MARK: - Private Methods
    private func setupUI() {
        
    }
    
    private func setupData() {
        
    }
    
    
    @IBAction func backClicked() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func stateAction(_ sender: UIButton) {
        if states.count > 0 {
            picker = UIPickerView.init()
            picker.tag = 1
            picker.delegate = self
            picker.dataSource = self
            picker.backgroundColor = UIColor.white
            picker.setValue(UIColor.black, forKey: "textColor")
            picker.autoresizingMask = .flexibleWidth
            picker.contentMode = .center
            picker.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
            self.view.addSubview(picker)
            picker.reloadAllComponents()
            
            toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
            toolBar.barStyle = .default
            toolBar.items = [UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped))]
            self.view.addSubview(toolBar)
        } else {
            self.stateAPI()
        }
    }
    
    @objc func onDoneButtonTapped() {
        toolBar.removeFromSuperview()
        picker.removeFromSuperview()
    }
    
    @IBAction func sportAction(_ sender: UIButton) {
        if self.sport.count > 0 {
            picker1 = UIPickerView.init()
            picker1.tag = 1
            picker1.delegate = self
            picker1.dataSource = self
            picker1.backgroundColor = UIColor.white
            picker1.setValue(UIColor.black, forKey: "textColor")
            picker1.autoresizingMask = .flexibleWidth
            picker1.contentMode = .center
            picker1.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
            self.view.addSubview(picker1)
            
            picker1.reloadAllComponents()
            
            toolBar1 = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
            toolBar1.barStyle = .default
            toolBar1.items = [UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped1))]
            self.view.addSubview(toolBar1)
        }
        else {
            self.sportAPI()
        }
    }
    
    @objc func onDoneButtonTapped1() {
        toolBar1.removeFromSuperview()
        picker1.removeFromSuperview()
    }
    
    @IBAction func verifyClicked() {
    
        if self.selectedState == nil {
            self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: "Please select state.")
            return
        }
        else if self.selectedSport == nil {
            self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: "Please select sport.")
          return
        }

        AppDefaults.selectedLoginType = .player

        var user = UserManager.shared.activeUser
        user?.userSport = self.selectedSport!.SportsName
        user?.userSportId = self.selectedSport!.SportsID
        user?.userState = self.selectedState!.StateName
        user?.userStateId = self.selectedState!.StateID
 
        UserManager.shared.activeUser = user
        AppDelegate.shared.presentRootViewController()
    }
}





extension PreferenceViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == picker {
            return states.count
        } else {
            return sport.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == picker {
            return states[row].StateName
        } else {
            return sport[row].SportsName
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == picker {
            self.selectedState = states[row]
            self.stateBtn.setTitle(states[row].StateName, for: .normal)
            self.stateBtn.setTitleColor(.black, for: .normal)
        } else {
            self.selectedSport = sport[row]
            self.sportBtn.setTitle(sport[row].SportsName, for: .normal)
            self.sportBtn.setTitleColor(.black, for: .normal)
        }
    }
}




extension PreferenceViewController {
    
    private func stateAPI() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getStateList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    print(i)
                    self.states.append(State.init(json: i)!)
                }
            case .failure:
                print(result)
            }
        }
    }
    
    private func sportAPI() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getSportsList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    print(i)
                    self.sport.append(Sport.init(json: i)!)
                }
            case .failure:
                print(result)
            }
        }
    }
    
}



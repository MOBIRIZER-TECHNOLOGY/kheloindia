//
//  ContactsViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 13/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class ContactsViewController: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    var contacts:[Contact] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.contactAPI()
    }
    
    //IBAction
    @IBAction func menuButtonClicked() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: nil)
    }
    
}

extension ContactsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as! ContactCell
        cell.setData(contacts[indexPath.row])
        cell.delagate = self
        return cell
    }
}

extension ContactsViewController : ContactCellDelegate {
    
    func didContactTapped(contact: Contact?) {
        print(contact!.ContactPhoneNO)
        if let url = URL(string: "tel://\(contact!.ContactPhoneNO)"),
            UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
 
    private func contactAPI() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getCotactList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    print(i)
                    let contact = Contact.init(json: i)
                    self.contacts.append(contact!)
                }
                if self.contacts.count > 0 {
                    self.tblView.reloadData()
                } else {
                    
                }
            case .failure:
                print(result)
            }
        }
    }
}

protocol ContactCellDelegate: class {
    func didContactTapped(contact: Contact?)
}


class ContactCell: UITableViewCell {
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var phoneLbl: UILabel!
    @IBOutlet weak var phoneBtn: UIButton!
    var contact: Contact? = nil
    var delagate: ContactCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setData(_ contact: Contact) {
        self.contact = contact
        self.nameLbl.text = contact.ContactName
        self.emailLbl.text = contact.ContactEmailID
        self.phoneLbl.text = contact.ContactPhoneNO
        self.phoneBtn.setTitle(contact.ContactPhoneNO, for: .normal)
    }
    
    @IBAction func callAction(_ sender: UIButton) {
        if let contact = self.contact {
            //Call Action
            delagate?.didContactTapped(contact: contact)

        }
    }
    
    
}

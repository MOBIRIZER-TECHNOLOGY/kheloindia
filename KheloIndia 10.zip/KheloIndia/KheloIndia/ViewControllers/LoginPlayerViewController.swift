//
//  LoginPlayerViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 11/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class LoginPlayerViewController: UIViewController {
    
    @IBOutlet weak var emailTxtFld: UITextField!
    @IBOutlet weak var passwordTxtFld: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        emailTxtFld.text = "pawan@gmail.com"
//        passwordTxtFld.text = "password"
//        emailTxtFld.text = "Sachin@gmail.com"
//        
//        emailTxtFld.text = "Sachin@gmail.com"
//        emailTxtFld.text = "arjun@gmail.com"
//        emailTxtFld.text = "virandra@gmail.com"
//        emailTxtFld.text = "dhoni@gmail.com"
//        emailTxtFld.text = "kapil@gmail.com"
//       emailTxtFld.text = "gita@gmail.com"
//       passwordTxtFld.text = "1234"
    }
 

    private func moveToNext(userId:Int,userName:String,userEmail:String) {
        var user = User()
        user.userName = userName
        user.userEmail = userEmail
        user.userId = userId
        UserManager.shared.activeUser = user
        AppDefaults.selectedLoginType = .player
        let vc = UIStoryboard.fetchPreferenceViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
  
    
    @IBAction func backClicked() {
      self.navigationController?.popViewController(animated: true)
    }
    
     //MARK:- IBActions
    @IBAction func verifyClicked() {
        
        let email = emailTxtFld?.text?.trimmed()
        let pwd = passwordTxtFld.text?.trimmed()
           var errorMessage = ""
           if !(email != nil && (email?.length)! > 0) {
               errorMessage = Constants.ErrorMessages.emptyUserName
           }
            else if !((pwd?.isValidPassword())!) {
                errorMessage = Constants.ErrorMessages.invalidPassword
            }
        
           if errorMessage.length > 0 {
               self.showAlertViewWithMessage(Constants.AlertTitles.errorTitle, message: errorMessage)
               return
           }
         
        
        if let email = emailTxtFld.text, !email.isEmpty, let pwd = passwordTxtFld.text, !pwd.isEmpty {
            self.playerLogin(email, pws: pwd)
        }
    }
}

//{
//    "status": "200",
//    "message": "success",
//    "result": {
//        "PlayerID": 1,
//        "PlayerEmailID": "Sachin@gmail.com"
//    }
//}
extension LoginPlayerViewController {
    
    func playerLogin(_ email: String, pws: String) {
        let str = "/\(email)/\(pws)"
        SVProgressHUD.show()
        ServiceLayer.requestWithData(router: Router.playerLogin, str) { (result: Result<Data
            , Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let resultData):
                do {
                    let responseObject = try JSONSerialization.jsonObject(with: resultData, options: .allowFragments) as? [String:Any]
                    print(responseObject ?? "")
                    
                    if ((responseObject!["status"] as! String) == "200") &&  (((responseObject!["result"]  as? [String:Any]) != nil)) {
                        
                        if let player = responseObject!["result"]  as? [String:Any], let userId = player["PlayerID"]  as? Int, let userEmail = player["PlayerEmailID"] as? String{
                            self.moveToNext(userId: userId, userName: "Player" , userEmail: userEmail )
                        }
                        
                    }
                    else if ((responseObject!["status"] as! String) == "200")  {
                        self.showAlertViewWithMessage("Error", message: "Please enter valid user name and password.")
                    } else {
                        self.showAlertViewWithMessage("Error", message: "Unable to login")
                    }
                    
                } catch {
                    let str = String(decoding: resultData, as: UTF8.self)
                    print("error: \(str)")
                    self.showAlertViewWithMessage("Error", message: str)
                }
            case .failure( let error):
                print(error.localizedDescription)
                self.showAlertViewWithMessage("Error",message: error.localizedDescription)

            }
        }
    }
}

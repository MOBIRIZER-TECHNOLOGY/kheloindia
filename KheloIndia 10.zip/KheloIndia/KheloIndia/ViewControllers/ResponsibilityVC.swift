//
//  ResponsibilityVC.swift
//  KheloIndia
//
//  Created by pawan singh on 16/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SVProgressHUD

class ResponsibilityVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var menuButton: UIButton!
    var responsibilities:[Responsibility] = []
    var isFromDashboard: Bool = false
    var selectedFunctionalArea: FunctionalArea? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupData()
    }
    
    func setupUI() {
        let image = isFromDashboard ? UIImage(named: "backArrowWhite") : UIImage(named: "menu")
        self.menuButton.setImage(image, for: .normal)
        tblView.register(UINib(nibName: "HotelCell", bundle: nil), forCellReuseIdentifier: "HotelCell")
    }
    
    func setupData() {
        self.getResponsibilityList()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return responsibilities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: String(describing: ResponsibilityCell.self), for: indexPath) as! ResponsibilityCell
        cell.setData(self.responsibilities[indexPath.row])
        return cell
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 175.0
//    }
    
    //IBAction
    @IBAction func menuButtonClicked() {
        if isFromDashboard {
            navigationController?.popViewController(animated: true)
        } else {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue:
                NotificationName.sideMenuToggle.value), object: nil)
        }
    }
    
}


extension ResponsibilityVC {
    
    private func getResponsibilityList() {
        SVProgressHUD.show()
        ServiceLayer.request(router: Router.getResponsibilityList, "/\(selectedFunctionalArea?.AreaID ?? 1)") { (result: Result<[[String:AnyObject]], Error>) in
            SVProgressHUD.dismiss()
            switch result {
            case .success (let data):
                for i in data {
                    self.responsibilities.append( Responsibility.init(json: i)! )
                }
                if self.responsibilities.count > 0 {
                    self.tblView.reloadData()
                } else {
                    
                }
            case .failure:
                print(result)
            }
        }
    }
    
}


class ResponsibilityCell: UITableViewCell {
    
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var subtitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    func setData(_ responsibility: Responsibility) {
        self.title.text = responsibility.ResponsibilityName
        self.subtitle.text = responsibility.ResponsibilityDesc
    }
}

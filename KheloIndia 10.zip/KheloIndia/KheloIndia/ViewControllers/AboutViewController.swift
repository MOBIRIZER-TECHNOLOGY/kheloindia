//
//  AboutViewController.swift
//  KheloIndia
//
//  Created by pawan singh on 13/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import WebKit

class AboutViewController: UIViewController {
    // IBOutlets
    @IBOutlet weak var webView: WKWebView!

    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
            let url = URL(string: "https://tourism.assam.gov.in/")
            let requestObj = URLRequest(url: url! as URL)
            webView.load(requestObj)
        } catch {
            print("Unexpected error: \(error).")
        }
        
    }
        
    //IBAction
    @IBAction func menuButtonClicked() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: nil)
    }
}

 

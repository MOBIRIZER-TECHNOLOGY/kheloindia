//
//  MenuViewController.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/11/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit
import SideMenu

class MenuViewController: UIViewController {
    // IBOutlets
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var userPhoneLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!

    // iVar
    
    var menuItems: [String] {
        switch AppDefaults.selectedLoginType {
        case .cdm:
            return ["HOME", "VENUE", "HOTEL", "EXPLORE ASSAM", "SCHEDULE", "CONTACTS", "FEEDBACK","LOGOUT"]
        case .player:
            return ["HOME", "VENUE", "HOTEL", "EXPLORE ASSAM", "SCHEDULE", "CONTACTS","LOGOUT"]
        case .volunteer:
            return ["HOME", "ATTENDANCE", "KIT DETAILS","SCHEDULE", "VENUE", "EXPLORE ASSAM", "GUIDE","LOGOUT"]
        case .none:
            return []
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setupData()
    }
    func setupData() {
        var user: User = UserManager.shared.activeUser
        usernameLabel.text = user.userName
        userPhoneLabel.text = user.userEmail
    }
    
    //IBAction
    @IBAction func crossClicked() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NotificationName.sideMenuToggle.value), object: self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(false)
        self.navigationController?.navigationBar.isHidden = false
    }
}

extension MenuViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: MenuCell.identifier) as? MenuCell {
            cell.configureCell(menuItems[indexPath.row])
            return cell
        }
        return UITableViewCell()
    }
}

extension MenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        NotificationCenter.default.post(name: NSNotification.Name(NotificationName.showVC.value), object: nil, userInfo: [NotificationKey.vcIndex.value: indexPath.row, NotificationKey.userType.value:AppDefaults.selectedLoginType])
    }
}

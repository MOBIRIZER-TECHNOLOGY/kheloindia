//
//  FeedbackSuccessMsgVC.swift
//  KheloIndia
//
//  Created by pawan singh on 15/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class FeedbackSuccessMsgVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func doneAction(_ sender: UIButton) {
    }
}

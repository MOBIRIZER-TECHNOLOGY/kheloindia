//
//  FoodView.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/14/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class FoodView: UIView {
    //IBOutlet
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var statusButton: UIButton!
    
    // iVar
    private var completion:((_ index: Int, _ status:Bool)->Void)?
    private var index = -1
    
    //MARK: - Initialization
    class func createFoodView(title:String?, status:Bool, index:Int, completion:((_ index: Int, _ status:Bool)->Void)?) -> FoodView {
        let view = Bundle.main.loadNibNamed("FoodView", owner: self, options: nil)?[0] as! FoodView
        view.titleLable.text = title
        view.statusButton.isSelected = status
        view.completion = completion
        view.index = index
        return view
    }
    
    //MARK: - IBAction
    @IBAction func statusButtonClicked() {
        statusButton.isSelected = !statusButton.isSelected
        completion?(self.index, statusButton.isSelected)
    }
}

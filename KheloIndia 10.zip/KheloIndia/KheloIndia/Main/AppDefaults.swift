//
//  AppDefaults.swift
//
//
//  Created by Pawan Joshi on 08/02/17.
//  Copyright © 2017 Appster. All rights reserved.
//

import UIKit
 
class AppDefaults {
    
    static var selectedLoginType: LoginType {
        set(newValue) {
            let rawValue = newValue.rawValue
            UserDefaults.standard.set(rawValue, forKey: "LoginType")
            UserDefaults.standard.synchronize()
        }
        get {
            guard let rawValue = UserDefaults.objectForKey("LoginType") as? Int else {
                return .none
            }
            return LoginType(rawValue: rawValue) ?? .none
        }
    }
    
}

//
//  Enums.swift
//  SillySocial
//
//  Created by Pawan Joshi on 29/05/18.
//  Copyright © 2018 Appster LLP. All rights reserved.
//

import Foundation
 
enum LoginType: Int {
    case player = 1
    case volunteer = 2
    case cdm = 3
    case none = 100
}

 

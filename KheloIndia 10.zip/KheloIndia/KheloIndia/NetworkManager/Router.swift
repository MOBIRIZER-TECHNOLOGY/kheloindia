//
//  Router.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/10/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation
 
enum Router {
    
    case getVenueList
    case getSportsList
    case getStateList
    case getHotelList
    case getCotactList
    case getFunctionalAreaList
    case getResponsibilityList
    case getScheduleList
    case verifyVolunteer
    case getAttendance
    case playerLogin
    case volunteerLogin
    case cdmLogin
    case saveVolunter
    case feedBack
    case getfeedBack
    case getTravel
    case setAttendance
    case kitlist
    case kit1
    case kit2
    case foodTravelStatus
    
    case blank

    var scheme: String {
        switch self {
            case .blank:
                return ""
            default:
                return "https"
        }
    }

    var host: String {
        switch self {
            case .blank:
                return ""
            default:
                return "kiyg2020.dnanetworks.in"
        }
    }

    var path: String {
        switch self {
        case .getVenueList:
            return "/appdata/venuelist"
        case .getSportsList:
            return "/appdata/sportslist"
        case .getStateList:
            return "/appdata/StateList"
        case .getHotelList:
            return "/appdata/HotelList"
        case .getCotactList:
            return "/appdata/CotactList"
        case .getFunctionalAreaList:
            return "/appdata/FunctionalAreaList"
        case .getResponsibilityList:
            return "/appdata/ResponsibilityList"
        case .getScheduleList:
            return "/appdata/ScheduleList"
        case .verifyVolunteer:
            return "/appdata/verifyVolunteer"
        case .getAttendance:
            return "/appdata/GetAttendance"
        case .playerLogin:
            return "/appdata/PlayerLogin"
        case .volunteerLogin:
            return "/appdata/VolunteerLogin"
        case .cdmLogin:
            return "/appdata/CdmLogin"
        case .saveVolunter:
            return "/appdata/saveVolunteerProfile"
        case .feedBack:
            return "/appdata/saveFeedback"
  
        case .getfeedBack:
            return "/appdata/getfeedback"

        case .getTravel:
            return "/appdata/getTravel"

        case .setAttendance:
            return "/appdata/Attendance"

        case .kitlist:
            return "/appdata/KitList"

        case .kit1:
            return "/appdata/Kit1"

        case .kit2:
            return "/appdata/Kit2"

        case .foodTravelStatus:
            return "/appdata/FoodTravelStatus"

        case .blank:
              return ""
        }
    }
    

    var parameters: [URLQueryItem] {
        let accessToken = "c32313df0d0ef512ca64d5b336a0d7c6"
        switch self {
        case .blank:
            return [URLQueryItem(name: "ids", value: "2759162243,2759143811"),
            URLQueryItem(name: "page", value: "1"),
            URLQueryItem(name: "access_token", value: accessToken)]
         default:
            return [URLQueryItem(name: "", value: nil)]

        }
    }

    var method: String {
        switch self {
            case .feedBack,.saveVolunter:
                   return "POST"
            default:
                return "GET"
        }
    }
    
}



/*
 private func venueAPI() {
     ServiceLayer.request(router: Router.getVenueList, nil) { (result: Result<[[String:AnyObject]], Error>) in
         switch result {
         case .success (let data):
                 for i in data {
                     print(i)
                     let venu = Venue.init(json: i)
                     self.venueList.append(venu!)
                 }
         case .failure:
             print(result)
         }
     }
 }
 
 
 
 
 private func sportAPI() {
     ServiceLayer.request(router: Router.getStateList, nil) { (result: Result<[[String:AnyObject]], Error>) in
         switch result {
         case .success (let data):
                 for i in data {
                     print(i)
                     let venu = Sport.init(json: i)
                 }
         case .failure:
             print(result)
         }
     }
 }
 
 
 
 
 
 private func stateAPI() {
     ServiceLayer.request(router: Router.getStateList, nil) { (result: Result<[[String:AnyObject]], Error>) in
         switch result {
         case .success (let data):
                 for i in data {
                     print(i)
                     let venu = State.init(json: i)
                 }
         case .failure:
             print(result)
         }
     }
 }
 
 
 
 
 private func hotelAPI() {
        ServiceLayer.request(router: Router.getHotelList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            switch result {
            case .success (let data):
                    for i in data {
                        print(i)
                        let venu = Hotel.init(json: i)
                    }
            case .failure:
                print(result)
            }
        }
    }
 
 
 
 
 private func contactAPI() {
        ServiceLayer.request(router: Router.getCotactList, nil) { (result: Result<[[String:AnyObject]], Error>) in
            switch result {
            case .success (let data):
                    for i in data {
                        print(i)
                        let venu = Contact.init(json: i)
                    }
            case .failure:
                print(result)
            }
        }
    }
 
 
 
 
 
 private func responsibilityAPI() {
        ServiceLayer.request(router: Router.getResponsibilityList, "/1") { (result: Result<[[String:AnyObject]], Error>) in
            switch result {
            case .success (let data):
                    for i in data {
                        print(i)
                        let venu = Responsibility.init(json: i)
                    }
            case .failure:
                print(result)
            }
        }
    }
 
 
 
 
 private func scheduleAPI() {
     ServiceLayer.request(router: Router.getScheduleList, "/All/All/All") { (result: Result<[[String:AnyObject]], Error>) in
         switch result {
         case .success (let data):
                 for i in data {
                     print(i)
                     let venu = Schedule.init(json: i)
                 }
         case .failure:
             print(result)
         }
     }
 }
 
 */
 
//(FunctionalAreaList > ResponsibilityList / AreaID)
// Contact
// ScheduleList/All/All/All

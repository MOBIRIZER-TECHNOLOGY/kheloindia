//
//  ServiceLayer.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/10/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation

class ServiceLayer {
    
    class func request(router: Router, _ extraParam: String?, completion: @escaping (Result<[[String:AnyObject]], Error>) -> ()) {
        var components = URLComponents()
        components.scheme = router.scheme
        components.host = router.host
        components.path = router.path
        //components.queryItems = router.parameters
        
        if let _ = extraParam {
            var path = router.path
            path = path + extraParam!
            components.path = path
        }
        
        guard let url = components.url else {
            let errorTemp = NSError(domain:"", code:300, userInfo:[NSLocalizedDescriptionKey: "Invalid Url"])
            completion(.failure(errorTemp))
            return
            
        }
        
        var urlRequest = URLRequest(url: url)
        print("---- URL ---")
        print(url)
        //print("-------")
        urlRequest.httpMethod = router.method
        let session = URLSession(configuration: .default)
        let dataTask = session.dataTask(with: urlRequest) { data, response, error in
            guard error == nil else {
                completion(.failure(error!))
                print(error?.localizedDescription as Any)
                return
            }
            guard response != nil else {
                let errorTemp = NSError(domain:"", code:400, userInfo:[NSLocalizedDescriptionKey: "Api not response"])
                completion(.failure(errorTemp))
                return
            }
            guard let data = data else {
                let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Response data not found"])
                completion(.failure(errorTemp))
                return
            }
            
            if data.count < 10 {
                let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Issue in parse data to json"])
                               completion(.failure(errorTemp))
                               return
            }
            
            let responseObject = try! JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:Any]
            
            print("---responseObject---")

            print(responseObject)
            print("-------")
            
            DispatchQueue.main.async {
                if (responseObject?["result"] as? [[String:Any]]) != nil {
                    let result = responseObject?["result"] as? [[String:AnyObject]]
                    completion(.success(result!))
                } else {
                    let errorTemp = NSError(domain:"", code:500, userInfo:[NSLocalizedDescriptionKey: "No result found"])
                    completion(.failure(errorTemp))
                }
            }
        }
        dataTask.resume()
    }
    

    class func requestWithData(router: Router, _ extraParam: String?, completion: @escaping (Result<Data, Error>) -> ()) {
        var components = URLComponents()
        components.scheme = router.scheme
        components.host = router.host
        components.path = router.path
        //components.queryItems = router.parameters
        
        if let _ = extraParam {
            var path = router.path
            path = path + extraParam!
            components.path = path
        }
        
        guard let url = components.url else {
            let errorTemp = NSError(domain:"", code:300, userInfo:[NSLocalizedDescriptionKey: "Invalid Url"])
            completion(.failure(errorTemp))
            return
            
        }
        
        var urlRequest = URLRequest(url: url)
        print("---- URL ---")
        print(url)
        urlRequest.httpMethod = router.method
        let session = URLSession(configuration: .default)
        let dataTask = session.dataTask(with: urlRequest) { data, response, error in
            guard error == nil else {
                completion(.failure(error!))
                print(error?.localizedDescription as Any)
                return
            }
            guard response != nil else {
                let errorTemp = NSError(domain:"", code:400, userInfo:[NSLocalizedDescriptionKey: "Api not response"])
                completion(.failure(errorTemp))
                return
            }
            guard let data = data else {
                let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Response data not found"])
                completion(.failure(errorTemp))
                return
            }
            
            if data.count < 10 {
                let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Issue in parse data to json"])
                               completion(.failure(errorTemp))
                               return
            }
            
            DispatchQueue.main.async {
                do {
                    let r = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:Any]
                    print(r as Any)
                    print("-------")
                    
                    completion(.success(data))
                } catch {
                   let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Response data not found"])
                   completion(.failure(errorTemp))
                }
            }
        }
        dataTask.resume()
    }
    
     
    
    class func requestWithPostData(router: Router, _ params: [String: Any]?, completion: @escaping (Result<Data, Error>) -> ()) {
        var components = URLComponents()
        components.scheme = router.scheme
        components.host = router.host
        components.path = router.path
        //components.queryItems = router.parameters
        
       
        
        guard let url = components.url else {
            let errorTemp = NSError(domain:"", code:300, userInfo:[NSLocalizedDescriptionKey: "Invalid Url"])
            completion(.failure(errorTemp))
            return
            
        }
        
        var urlRequest = URLRequest(url: url)
        
        
        
        
        var jsonData:Data?
        do {
            jsonData = try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted)
        } catch {
            print(error.localizedDescription)
        }
 

        urlRequest.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Accept")
        
        
        print("---- URL ---",url)
        print("---- Params ---",params)

        urlRequest.httpMethod = router.method

        urlRequest.httpBody = jsonData
        
        let session = URLSession(configuration: .default)
        let dataTask = session.dataTask(with: urlRequest) { data, response, error in
            guard error == nil else {
                completion(.failure(error!))
                print(error?.localizedDescription as Any)
                return
            }
            guard response != nil else {
                let errorTemp = NSError(domain:"", code:400, userInfo:[NSLocalizedDescriptionKey: "Api not response"])
                completion(.failure(errorTemp))
                return
            }
            guard let data = data else {
                let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Response data not found"])
                completion(.failure(errorTemp))
                return
            }
            
            if data.count < 10 {
                let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Issue in parse data to json"])
                               completion(.failure(errorTemp))
                               return
            }
            
            DispatchQueue.main.async {
                do {
                    let r = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:Any]
                    print(r as Any)
                    print("-------")
                    
                    completion(.success(data))
                } catch {
                   let errorTemp = NSError(domain:"", code:401, userInfo:[NSLocalizedDescriptionKey: "Response data not found"])
                   completion(.failure(errorTemp))
                }
            }
        }
        dataTask.resume()
    }
    
}

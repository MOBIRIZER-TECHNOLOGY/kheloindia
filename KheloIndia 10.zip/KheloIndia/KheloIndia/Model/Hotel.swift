//
//  Hotel.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation

struct Hotel: Codable {
    let HotelID: Int
    let HotelName: String
    let HotelAddress: String
    let GeoLocation: String
}

extension Hotel {
    init?(json: [String: Any]) {
        guard
            let HotelID = json["HotelID"] as? Int,
            let HotelName = json["HotelName"] as? String,
            let HotelAddress = json["HotelAddress"] as? String,
            let GeoLocation = json["GeoLocation"] as? String
        else { return nil }
        self.HotelID = HotelID
        self.HotelName = HotelName
        self.HotelAddress = HotelAddress
        self.GeoLocation = GeoLocation
    }
}


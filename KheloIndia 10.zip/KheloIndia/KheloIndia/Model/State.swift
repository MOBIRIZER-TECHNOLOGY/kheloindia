//
//  State.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation

struct State: Codable {
    let StateID: Int
    let StateName: String
}

extension State {
    init?(json: [String: Any]) {
        guard
            let StateID = json["StateID"] as? Int,
            let StateName = json["StateName"] as? String
           
        else { return nil }
        self.StateID = StateID
        self.StateName = StateName
    }
}

//
//  Schedule.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation



struct Schedule: Codable {
    let scheduleID: Int?
    let eventName: String?
    let venueID: Int?
    let venueName: String?
    let sportsID: Int?
    let sportsName, eventTime, eventDate, result: String?

}
   enum CodingKeys: String, CodingKey {
       case scheduleID = "ScheduleID"
       case eventName = "EventName"
       case venueID = "VenueID"
       case venueName = "VenueName"
       case sportsID = "SportsID"
       case sportsName = "SportsName"
       case eventTime = "EventTime"
       case eventDate = "EventDate"
       case result = "Result"
   }
 
extension Schedule {
    init?(json: [String: Any]) {
       
        guard
            let scheduleID = json["ScheduleID"] as? Int,
            let eventName = json["EventName"] as? String,
            let venueID = json["VenueID"] as? Int,
            let venueName = json["VenueName"] as? String,
            let sportsID = json["SportsID"] as? Int,
            let sportsName = json["SportsName"] as? String,
            let eventTime = json["EventTime"] as? String,
            let eventDate = json["EventDate"] as? String,
            let result = json["Result"] as? String
            
        else { return nil }
 
        self.scheduleID = scheduleID
        self.eventName = eventName
        self.venueID = venueID
        self.venueName = venueName
        self.sportsID = sportsID
        self.sportsName = sportsName
        self.eventTime = eventTime
        self.eventDate = eventDate
        self.result = result
    }
}









//// MARK: - Schedule
//struct Schedule: Codable {
//    let scheduleID: Int?
//    let eventName: String?
//    let venueID: Int?
//    let venueName: String?
//    let sportsID: Int?
//    let sportsName, eventTime, eventDate, result: String?
//
//    enum CodingKeys: String, CodingKey {
//        case scheduleID = "ScheduleID"
//        case eventName = "EventName"
//        case venueID = "VenueID"
//        case venueName = "VenueName"
//        case sportsID = "SportsID"
//        case sportsName = "SportsName"
//        case eventTime = "EventTime"
//        case eventDate = "EventDate"
//        case result = "Result"
//    }
//}
//
//// MARK: Schedule convenience initializers and mutators
//
//extension Schedule {
//    init(data: Data) throws {
//        self = try newJSONDecoder().decode(Schedule.self, from: data)
//    }
//
//    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
//        guard let data = json.data(using: encoding) else {
//            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
//        }
//        try self.init(data: data)
//    }
//
//    init(fromURL url: URL) throws {
//        try self.init(data: try Data(contentsOf: url))
//    }
//
//    func with(
//        scheduleID: Int?? = nil,
//        eventName: String?? = nil,
//        venueID: Int?? = nil,
//        venueName: String?? = nil,
//        sportsID: Int?? = nil,
//        sportsName: String?? = nil,
//        eventTime: String?? = nil,
//        eventDate: String?? = nil,
//        result: String?? = nil
//    ) -> Schedule {
//        return Schedule(
//            scheduleID: scheduleID ?? self.scheduleID,
//            eventName: eventName ?? self.eventName,
//            venueID: venueID ?? self.venueID,
//            venueName: venueName ?? self.venueName,
//            sportsID: sportsID ?? self.sportsID,
//            sportsName: sportsName ?? self.sportsName,
//            eventTime: eventTime ?? self.eventTime,
//            eventDate: eventDate ?? self.eventDate,
//            result: result ?? self.result
//        )
//    }
//
//    func jsonData() throws -> Data {
//        return try newJSONEncoder().encode(self)
//    }
//
//    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
//        return String(data: try self.jsonData(), encoding: encoding)
//    }
//}
//
//// JSONSchemaSupport.swift
//
//import Foundation
//
//// MARK: - Helper functions for creating encoders and decoders
//
//func newJSONDecoder() -> JSONDecoder {
//    let decoder = JSONDecoder()
//    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
//        decoder.dateDecodingStrategy = .iso8601
//    }
//    return decoder
//}
//
//func newJSONEncoder() -> JSONEncoder {
//    let encoder = JSONEncoder()
//    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
//        encoder.dateEncodingStrategy = .iso8601
//    }
//    return encoder
//}
//
//
//
//// MARK: - Welcome
//struct Schedule: Codable {
//    let scheduleID: Int?
//    let eventName: String?
//    let venueID: Int?
//    let venueName: String?
//    let sportsID: Int?
//    let sportsName, eventTime, eventDate, result: String?
//
//    enum CodingKeys: String, CodingKey {
//        case scheduleID = "ScheduleID"
//        case eventName = "EventName"
//        case venueID = "VenueID"
//        case venueName = "VenueName"
//        case sportsID = "SportsID"
//        case sportsName = "SportsName"
//        case eventTime = "EventTime"
//        case eventDate = "EventDate"
//        case result = "Result"
//    }
//}

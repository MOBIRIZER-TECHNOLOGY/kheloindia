//
//  Sport.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation

struct Sport: Codable {
    let SportsID: Int
    let SportsName: String
}

extension Sport {
    init?(json: [String: Any]) {
        guard
            let SportsID = json["SportsID"] as? Int,
            let SportsName = json["SportsName"] as? String
           
        else { return nil }
        self.SportsID = SportsID
        self.SportsName = SportsName
    }
}

//
//  Venue.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/10/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation

struct Venue: Codable {
    let VenueID: Int
    let VenueName: String
    let VenueAddress: String
    let GeoLocation: String
}

extension Venue {
    init?(json: [String: Any]) {
        guard
            let VenueID = json["VenueID"] as? Int,
            let VenueName = json["VenueName"] as? String,
            let VenueAddress = json["VenueAddress"] as? String,
            let GeoLocation = json["GeoLocation"] as? String
        else { return nil }
        self.VenueID = VenueID
        self.VenueName = VenueName
        self.VenueAddress = VenueAddress
        self.GeoLocation = GeoLocation
    }
}

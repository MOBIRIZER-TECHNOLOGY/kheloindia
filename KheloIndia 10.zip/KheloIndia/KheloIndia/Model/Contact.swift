//
//  Contact.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation

struct Contact: Codable {
    let ContactID: Int
    let ContactName: String
    let ContactPhoneNO: String
    let ContactEmailID: String
}

extension Contact {
    init?(json: [String: Any]) {
        guard
            let ContactID = json["ContactID"] as? Int,
            let ContactName = json["ContactName"] as? String,
            let ContactPhoneNO = json["ContactPhoneNO"] as? String,
            let ContactEmailID = json["ContactEmailID"] as? String
        else { return nil }
        self.ContactID = ContactID
        self.ContactName = ContactName
        self.ContactPhoneNO = ContactPhoneNO
        self.ContactEmailID = ContactEmailID
    }
}

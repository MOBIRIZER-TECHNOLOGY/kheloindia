//
//  Responsibility.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation


struct Responsibility: Codable {
    let AreaID: Int
    let ResponsibilityName: String
    let ResponsibilityDesc: String
}

extension Responsibility {
    init?(json: [String: Any]) {
        guard
            let AreaID = json["ResponsibilityID"] as? Int,
            let ResponsibilityName = json["ResponsibilityName"] as? String,
            let ResponsibilityDesc = json["ResponsibilityDesc"] as? String
        else { return nil }
        self.AreaID = AreaID
        self.ResponsibilityName = ResponsibilityName
        self.ResponsibilityDesc = ResponsibilityDesc
    }
}

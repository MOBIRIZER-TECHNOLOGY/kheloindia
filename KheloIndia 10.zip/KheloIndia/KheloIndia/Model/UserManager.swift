//
//  UserManager.swift
//
//  Created by Sourabh Bhardwaj on 01/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import UIKit

/// User Manager - manages all feature for User model
class UserManager: NSObject {

    // MARK: Declaration for string constants to be used to decode and also serialize.
    private struct SerializationKeys {
        static let activeUser = "activeUser"
        static let accessToken = "accessToken"
        static let userEmail = "userEmail"
    }

    var accessToken: String? {
        get {
            return UserDefaults.objectForKey(SerializationKeys.accessToken) as? String
        }
        set {
            UserDefaults.setObject(newValue as AnyObject, forKey: SerializationKeys.accessToken)
        }
    }

    fileprivate var _activeUser: User?

    var activeUser: User! {
        get {
            return _activeUser
        }
        set {
            _activeUser = newValue

            if let _ = _activeUser {
                saveActiveUser()
            }
        }
    }

    // MARK: - Singleton Instance
    class var shared: UserManager {
        struct Singleton {
            static let instance = UserManager()
        }
        return Singleton.instance
    }

    fileprivate override init() {
        // initiate any queues / arrays / filepaths etc
        super.init()

        // Load last logged user data if exists
        if isLoggedInUser() {
            loadActiveUser()
        }
    }

    func isLoggedInUser() -> Bool {

        guard let _ = UserDefaults.objectForKey(SerializationKeys.activeUser)
        else {
            return false
        }
        return true
    }

    // MARK: - KeyChain / User Defaults / Flat file / XML

    /**
     Load last logged user data, if any
     */
    func loadActiveUser() {
 
        let encoded = UserDefaults.standard.object(forKey:SerializationKeys.activeUser) as! Data
        let user = try! PropertyListDecoder().decode(User.self, from: encoded)

        self.activeUser = user
    }

    func lastLoggedUserEmail() -> String? {
        return UserDefaults.objectForKey(SerializationKeys.userEmail) as? String
    }

    /**
     Save current user data
     */
    func saveActiveUser() {

        try? UserDefaults.standard.set(PropertyListEncoder().encode( self.activeUser), forKey: SerializationKeys.activeUser)

    }

    /**
     Delete current user data
     */
    func deleteActiveUser() {
         // remove active user from storage
        UserDefaults.removeObjectForKey(SerializationKeys.activeUser)
        // free user object memory
        self.activeUser = nil
    }

    func requestRatingForPostVideo(_: Bool) {
    }
}

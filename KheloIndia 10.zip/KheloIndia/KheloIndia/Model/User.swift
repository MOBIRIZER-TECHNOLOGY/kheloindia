//
//  User.swift
//  KheloIndia
//
//  Created by pawan singh on 13/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

import Foundation

struct User: Codable {
       var userType: Int?
       var userName: String?
       var userEmail: String?

       var userState: String?
       var userSport: String?
       
       var userStateId: Int?
       var userSportId: Int?
    
       var userId: Int?
}


//class User: Codable {
//       var userType: Int = 0
//       var userName: String = ""
//       var userEmail: String = ""
//
//       var userState: String = ""
//       var userSport: String = ""
//
//       var userStateId: Int = 0
//       var userSportId: Int = 0
//
//       var userId: Int = 0
//}

//class User: NSObject, NSCoding {
//
//    private let kUserTypeKey: String = "type"
//    private let kUserNameKey: String = "name"
//    private let kUserEmailKey: String = "email"
//    private let KUserState = "userState"
//    private let KUserSport = "userSport"
//
//    private let KUserStateId = "userStateId"
//    private let KUserSportId = "userSportId"
//
//    private let KUserId = "userId"
//
//    var userType: Int = 0
//    var userName: String = ""
//    var userEmail: String = ""
//
//    var userState: String = ""
//    var userSport: String = ""
//
//    var userStateId: Int = 0
//    var userSportId: Int = 0
//
//    var userId: Int = 0
//
//    func encode(with coder: NSCoder) {
//        coder.encode(userType, forKey: kUserTypeKey)
//        coder.encode(userName, forKey: kUserNameKey)
//        coder.encode(userEmail, forKey: kUserEmailKey)
//        coder.encode(userState, forKey: KUserState)
//        coder.encode(userSport, forKey: KUserSport)
//        coder.encode(userStateId, forKey: KUserStateId)
//        coder.encode(userSportId, forKey: KUserSportId)
//        coder.encode(userId, forKey: KUserId)
//    }
//
//
//    required init?(coder: NSCoder) {
//        super.init()
//        userType = coder.decodeInteger(forKey: kUserTypeKey) as? Int ?? 0
//        userName = coder.decodeObject(forKey: kUserNameKey) as? String ?? ""
//        userEmail = coder.decodeObject(forKey: kUserEmailKey) as? String ?? ""
//        userState = coder.decodeObject(forKey: KUserState) as? String ?? ""
//        userSport = coder.decodeObject(forKey: KUserSport) as? String ?? ""
//        userStateId = coder.decodeInteger(forKey: KUserStateId) as? Int ?? 0
//        userSportId = coder.decodeInteger(forKey: KUserSportId) as? Int ?? 0
//        userId = coder.decodeInteger(forKey: KUserId) as? Int ?? 0
//    }
//
//    override init() {
//        super.init()
//    }
//
//}
//
//

//
//  FunctionalArea.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation


struct FunctionalArea: Codable {
    let AreaID: Int
    let AreaName: String
}

extension FunctionalArea {
    init?(json: [String: Any]) {
        guard
            let AreaID = json["AreaID"] as? Int,
            let AreaName = json["AreaName"] as? String
           
        else { return nil }
        self.AreaID = AreaID
        self.AreaName = AreaName
    }
}

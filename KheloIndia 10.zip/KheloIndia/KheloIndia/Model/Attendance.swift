//
//  Attendance.swift
//  NetworkApp
//
//  Created by Narender Kumar on 12/11/19.
//  Copyright © 2019 Narender Kumar. All rights reserved.
//

import Foundation

struct Attendance: Codable {
    let InTime: String
    let OutTime: String
}

extension Attendance {
    init?(json: [String: Any]) {
        guard
            let InTime = json["InTime"] as? String,
            let OutTime = json["OutTime"] as? String
           
        else { return nil }
        self.InTime = InTime
        self.OutTime = OutTime
    }
}

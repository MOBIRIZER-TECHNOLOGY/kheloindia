//
//  UIStoryboard+Extension.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import Foundation
import UIKit

extension UIStoryboard {
    
    static  func mainStoryboard() -> UIStoryboard {
        return UIStoryboard(name: Constants.StoryboardName.main, bundle: nil)
    }
    
    // MARK: - ViewControllers
    static func fetchLoginViewController() -> LoginViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.loginVC) as! LoginViewController
    }
    
    static func fetchOTPViewController() -> OTPViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.otpVC) as! OTPViewController
    }
    
    static func fetchBankDetailViewController() -> BankDetailViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.bankDetailVC) as! BankDetailViewController
    }
    
    static func fetchPreferenceViewController() -> PreferenceViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.preferenceVC) as! PreferenceViewController
    }
    
    static func fetchMenuViewController() -> MenuViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.menuVC) as! MenuViewController
    }
    
    static func fetchContainerViewController() -> ContainerViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.containerVC) as! ContainerViewController
    }
    
    static func fetchDashboardController() -> DashboardViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.dashboardVC) as! DashboardViewController
    }
    
    static func fetchSportViewController() -> SportViewController {
          return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.sportVC) as! SportViewController
    }
    
    static func fetchHotelViewController() -> HotelsViewController {
            return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.hotelVC) as! HotelsViewController
      }
    
    static func fetchVenueViewController() -> VenueViewController {
            return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.venuVC) as! VenueViewController
      }
    
    
    static func fetchResultsViewController() -> ResultsViewController {
               return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.resultVC) as! ResultsViewController
         }
    
    static func fetchContactsViewController() -> ContactsViewController {
               return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.contactVC) as! ContactsViewController
         }
    
    static func fetchAboutViewController() -> AboutViewController {
               return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.aboutVC) as! AboutViewController
         }
    
    static func fetchVolunteerLoginViewController() -> LoginVolunteerViewController {
               return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.loginVolunteerVC) as! LoginVolunteerViewController
         }
    static func fetchCDMLoginViewController() -> LoginCDMViewController {
               return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.loginCDMVC) as! LoginCDMViewController
         }
    
    static func fetchPlayerLoginViewController() -> LoginPlayerViewController {
               return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.loginPlayerVC) as! LoginPlayerViewController
         }
    
 
    static func fetchNewFeedbackViewController() -> NewFeedbackVC {
                  return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.newFeedBackVC) as! NewFeedbackVC
    }
    
    static func fetchAttendanceViewController() -> AttendanceViewController {
                  return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.attendanceVC) as! AttendanceViewController
    }
    
    static func fetchFilterViewController() -> FilterViewController {
            return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.filterVC) as! FilterViewController
       }
    
    
    static func fetchKitViewController() -> KitDetailsViewController {
                  return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.kitVC) as! KitDetailsViewController
    }
    
    static func fetchGuideViewController() -> GuideViewController {
                  return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.guideVC) as! GuideViewController
    }
    
    static func fetchResponsibilityViewController() -> ResponsibilityVC {
          let vc = UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.responsibilityVC) as! ResponsibilityVC
        return vc
    }
    
    static func fetchTravelAndFoodViewController() -> TravelAndFoodViewController {
           let vc = UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: Constants.ViewControllerName.travelAndFoodViewController) as! TravelAndFoodViewController
         return vc
     }
}
  



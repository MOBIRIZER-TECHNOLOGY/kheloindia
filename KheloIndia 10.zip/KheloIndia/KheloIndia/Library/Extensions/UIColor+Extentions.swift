//
//  UIColor+Extentions.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    static var appBackgroundColor = UIColor.init(red: 255/255, green: 118/255, blue: 35/255, alpha: 0.59)
}

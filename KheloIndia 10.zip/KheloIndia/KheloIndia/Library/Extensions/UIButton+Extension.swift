//
//  UIButton+Extension.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import Foundation
import UIKit

extension UIButton {
    func setTitleForAll(title: String?) {
        self.setTitle(title, for: UIControl.State.normal)
        self.setTitle(title, for: UIControl.State.disabled)
        self.setTitle(title, for: UIControl.State.selected)
        self.setTitle(title, for: UIControl.State.highlighted)
    }
}

//
//  Constants.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 10/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import Foundation

struct Constants {
    struct StoryboardName {
        static let main = "Main"
        static let home = "Home"
    }
    
    struct ViewControllerName {
        static let loginVC = "LoginViewController"
        static let otpVC = "OTPViewController"
        static let bankDetailVC = "BankDetailViewController"
        static let preferenceVC = "PreferenceViewController"
        static let dashboardVC = "DashboardViewController"
        static let menuVC = "MenuViewController"
        static let sportVC = "SportViewController"
        static let hotelVC = "HotelsViewController"
        static let venuVC = "VenueViewController"
        static let resultVC = "ResultsViewController"
        static let contactVC = "ContactsViewController"
        static let aboutVC = "AboutViewController"
        
        static let loginVolunteerVC = "LoginVolunteerViewController"
        static let loginCDMVC = "LoginCDMViewController"
        static let loginPlayerVC = "LoginPlayerViewController"

        static let kitDetailsVC = "KitDetailsViewController"
        static let newFeedBackVC = "NewFeedbackVC"
        
        static let containerVC = "ContainerViewController"
        static let attendanceVC = "AttendanceViewController"
        static let filterVC = "FilterViewController"

        
        static let kitVC = "KitDetailsViewController"
        static let guideVC = "GuideViewController"
        static let responsibilityVC = "ResponsibilityVC"
        static let travelAndFoodViewController = "TravelAndFoodViewController"

    }
    
    
    struct ResponseKeys {
        static let success = "success"
        static let status = "status"
        static let result = "result"
        static let message = "message"
        static let totalPages = "totalPages"
        static let totalCount = "totalCount"
        static let currentPage = "currentPage"
        static let cartCount = "cartCount"
        static let numberOfResults = "numberOfResults"
        static let contentList = "contentList"
        static let data = "data"
        static let contactUser = "contactUser"
        static let look = "look"
        static let liked = "liked"
        static let name = "name"
        static let notFetchedCount = "notFetchedCount"
        static let textCampaignDelay = "textCampaignDelay"
    }
    
    // MARK: AlertTitleMessages
    struct AlertActionTitles {
        static let alertActionTrue = "Yes"
        static let alertActionFalse = "No"
        static let alertActionDelete = "Delete"
        static let alertActionFlag = "Flag"
        static let alertActionEdit = "Edit"
        static let alertActionCancel = "Cancel"
        static let alertActionReport = "Report"
        static let alertContactAdmin = "Contact Admin"
        static let alertActionUnfollow = "Unfollow"
        static let alertReportChat = "Report User"
        static let alertDeleteChat = "Delete Chat"
    }
    
    struct SocialURLs {
        static let facebook = "https://www.facebook.com/myrepcard"
        static let twitter = "https://twitter.com/myrepcard"
        static let instagram = "https://www.instagram.com/myrepcard/"
        static let youtube = "https://www.youtube.com/channel/UCHdB_aL07inimlYrCAFSm6g"
    }

    
    // MARK: Tokens
    struct Tokens {
        static let mixpanelToken: String = ""
        static let flurryAppID: String = ""
        static let googleAnalyticsAppID: String = ""
    }
    

    struct NotificationNameIdentifiers {
        static let contactAddedNotificationIdentifier = "CONTACT_ADDED"
        static let recruitAddedNotificationIdentifier = "RECRUIT_ADDED"
        static let recruitVideoLinkAddedNotificationIdentifier = "RECRUIT_VIDEO_LINK_ADDED"
        static let prospectAddedNotificationIdentifier = "PROSPECT_ADDED"
        static let customerAddedNotificationIdentifier = "CUSTOMER_ADDED"
    }

    struct NotificationNames {
        static let contactAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.contactAddedNotificationIdentifier)
        static let recruitAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.recruitAddedNotificationIdentifier)
        static let prospectAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.prospectAddedNotificationIdentifier)
        static let customerAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.customerAddedNotificationIdentifier)
    }
    
    // MARK: ErrorMessages
    struct ErrorMessages {

        // Network Errors
        static let networkDisconnected: String = "No internet connection available."
        static let networkError: String = "Server is not responding."
        static let loadingError: String = "Could not load page."
        static let sessionExpireError: String = "Your session has expired."
        static let responseParsingError: String = "Couldn't parse the response"
        static let loginFailed: String = "Sorry, we can't log you in right now."
        static let singupFailed: String = "An error occurred while sign up."
        static let imageUploadFailed: String = "Image couldn't be uploaded."
        static let imageUploadSuccess: String = "image uploaded successfully"
        static let serverConnectionError: String = "Couldn't connect to server"

        // Validation Errors
        static let emptyPassword: String = "Please enter password."
        static let emptyPhone: String = "Please enter phone number."

        static let emptyConfimPassword: String = "Please enter confirm password."
        static let passwordMismatch: String = "Password and Confirm Password do not match."
        static let emptyFullName: String = "Please enter full name"
        static let emptyFirstName: String = "Please enter first name"
        static let emptyLastName: String = "Please enter last name"
        static let emptyEmail: String = "Please enter an email"
        
        static let emptyUserName: String = "Please enter user name"

        static let emptyCompanyName: String = "Please enter company name"
        static let emptyIndustryName: String = "Please select an industry"
        
        static let emptyName: String = "Please enter an name"

        static let emptyProfileImage: String = "Please add profile picture"
        static let invalidEmail: String = "Please enter a valid email."
        static let invalidPhone: String = "Please enter a valid phone number."
        static let emptyTitle: String = "Please enter a title."

        static let invalidPassword: String = "Password must contain minimum 4 characters."
        static let matchNewPassword: String = "New and current password must not be same."
        static let descriptionOutOfRange: String = "Description can not be more than 100 characters long"
        static let invalidUrl: String = "Invalid Url."
        static let mismatchPassword: String = "New password and confirm password do not match."
        static let emptyEventCollection: String = "No events to show"
        static let subEmptyEventCollection: String = "No events to show"
        static let emptySearchCollection: String = "No records found"
        static let emptyNotificationCollection: String = "No notifications to show"
        
        static let INVALID_URL: String = "Invalid Url."
        
        static let ALREADY_LOGIN: String = "You already have a valid password."
        
        static let MISMATCH_PASSWORD: String = "New password and confirm password do not match."
        static let EMPTY_PASSWORD: String = "Please enter password."
        static let INVALID_PASSWORD: String = "Only alphanumaric letters and !@#$ are allowed"
        static let SAME_PASSWORD: String = "New password and current password should not be same."


    }

    
    // MARK: AlertTitles
    struct AlertTitles {
        static let repcardTitle = "KheloIndia"
        static let errorTitle = repcardTitle
        static let warningTitle = "Warning"
        static let logoutTitle = "Logout"
        static let successTitle = "Success"
        static let confirmationTitle = "Please Confirm"
        static let passwordTitle = "Enter Password"
        static let deleteTitle = "Delete!"
        static let flagTitle = "Flag!"
    }
    
    // MARK: AlertTitleMessages
    struct AlertTitleMessages {
        static let confirmationTitleMessage = "Are you sure?"
        static let emailUnsupported = "Can't send the email. Please configure an Email account in Settings or check your Internet connection."
        static let smsUnsupported = "This device can't send a text message right now."
        static let emailChangePasswordVerification = "You need to verify your password, in order to change your email address"
        static let treeDeleteConfirmationMessage = "Please confirm that you want to delete this tree. Once a tree is deleted, all it's contents will be permanently removed"
        static let treeLeaveConfirmationMessage = "Please confirm that you want to leave this tree. Once you leave you no longer will have any access or notifications from this tree and the chat group."
        static let flagUserConfirmationMessage = "Please confirm if you want to flag this user. Once a user is flagged MemTree will review this request, and take neccessory actions."
        static let branchDeleteConfirmationMessage = "Please confirm that you want to delete this branch. Once a branch is deleted, all it's contents will be permanently removed"
        static let eventDeleteConfirmationMessage = "Please confirm that you want to delete this event. Once a event is deleted, all it's contents will be permanently removed"
        static let twigDeleteConfirmationMessage = "Please confirm that you want to delete this Twig. Once a twig is deleted, all it's contents will be permanently removed"
        static let leaveTreeMessage = "You have been remove from this tree."
        static let invalidInput: String = "The input is invalid or not complete"
        static let insallFBMessanger: String = "Please install facebook messenger for itunes."
        static let trialExpiredMessage: String = "Your trial period has been expired, please purchase a subscription"
        static let trialStartedMessage: String = "Your trial period has began! You can send 5 business card for free, after that its just $9.99(USD) per month for unlimited access."
        static let trialRemainingMessage: String = "Your trial has 1 more free business card left. Please purchase a $9.99(USD) subscription for unlimited access!"
        static let trialPurchasedMessage: String = "Thanks for purchasing subscription, now you can enjoy unlimitted business cards at $9.99(USD) per month."
        static let trialCancelMessage: String = "We’d hate to see you go! Please confirm if you wanna proceed with canceling the subscription?"
        static let somethingWrong: String = "Something went wrong."
        static let invalidYoutubeUrl: String = "Please enter valid youtube url."
        static let invalidURL: String = "The Url is invalid. Please add complete social URL, add http or https as required!"


    }

    struct ViewControllerIdentifiers {
        static let loginViewController = "LoginViewController"
    }
    
}




enum UserType {
    case player
    case manager
    case volunteer
}

enum NotificationName: String {
    case sideMenuToggle = "TOGGLE_SIDEMENU"
    case showVC = "SHOW_VIEW_CONTROLLER"
    
    var value:String {
        return self.rawValue
    }
}

enum NotificationKey: String {
    case vcIndex = "VC_INDEX"
    case userType = "USER_TYPE"
    
    var value:String {
        return self.rawValue
    }
}
















//
//
//import Foundation
//
//struct Constants {
//    
//    enum UserType: Int {
//        case company = 3
//        case rep = 2
//    }
//    
//    enum PeopleType: Int {
//        case customer = 0
//        case prospect = 1
//        case recruit = 2
//        case contact = 3
//    }
//    
//    enum Expereience: Int {
//        case rookie = 0
//        case vet = 1
//    }
//    
//    struct ImageTypes {
//        static let businessCardImage = "3"
//        static let companyLogoImage = "2"
//        static let profileImage = "1"
//        static let recuritImage = "10"
//        static let recuritProfileImage = "1"
//        static let recuritLogoImage = "2"
//
//    }
//    
//    struct ResponseKeys {
//        static let success = "success"
//        static let status = "status"
//        static let result = "result"
//        static let message = "message"
//        static let totalPages = "totalPages"
//        static let totalCount = "totalCount"
//        static let currentPage = "currentPage"
//        static let cartCount = "cartCount"
//        static let numberOfResults = "numberOfResults"
//        static let contentList = "contentList"
//        static let data = "data"
//        static let contactUser = "contactUser"
//        static let look = "look"
//        static let liked = "liked"
//        static let name = "name"
//        static let notFetchedCount = "notFetchedCount"
//        static let textCampaignDelay = "textCampaignDelay"
//    }
//    
//    // MARK: AlertTitleMessages
//    struct AlertActionTitles {
//        static let alertActionTrue = "Yes"
//        static let alertActionFalse = "No"
//        static let alertActionDelete = "Delete"
//        static let alertActionFlag = "Flag"
//        static let alertActionEdit = "Edit"
//        static let alertActionCancel = "Cancel"
//        static let alertActionReport = "Report"
//        static let alertContactAdmin = "Contact Admin"
//        static let alertActionUnfollow = "Unfollow"
//        static let alertReportChat = "Report User"
//        static let alertDeleteChat = "Delete Chat"
//    }
//    
//    struct SocialURLs {
//        static let facebook = "https://www.facebook.com/myrepcard"
//        static let twitter = "https://twitter.com/myrepcard"
//        static let instagram = "https://www.instagram.com/myrepcard/"
//        static let youtube = "https://www.youtube.com/channel/UCHdB_aL07inimlYrCAFSm6g"
//    }
//
//    struct Env {  //development
//        static let Domain = "https://dev.myrepcard.com/"
//        static let StripPublishableKey = "pk_test_UMnZaGORRbufrpfemsDWUpZL"
//        static let GADMobileAdsAppID = "ca-app-pub-9133707516557572~5010711734"
//        static let GADInterstitialUnitID = "ca-app-pub-9133707516557572/6727118085"
//        static let GMSServicesAPIKey = "AIzaSyClVr1xMsLQJ73ynX8OADOkzUV6djO6wVI"
//        static let GMSPlacesClientAPIKey  = "AIzaSyClVr1xMsLQJ73ynX8OADOkzUV6djO6wVI"
//        static let CountryCode = "+1"
//    }
//    
////    struct Env {  //beta/qa
////        static let Domain = "https://qa.myrepcard.com/"
////        static let StripPublishableKey = "pk_test_UMnZaGORRbufrpfemsDWUpZL"
////        static let GADMobileAdsAppID = "ca-app-pub-9133707516557572~5010711734"
////        static let GADInterstitialUnitID = "ca-app-pub-9133707516557572/6727118085"
////        static let GMSServicesAPIKey = "AIzaSyClVr1xMsLQJ73ynX8OADOkzUV6djO6wVI"
////        static let GMSPlacesClientAPIKey  = "AIzaSyClVr1xMsLQJ73ynX8OADOkzUV6djO6wVI"
////        static let CountryCode = "+1"
////    }
//    
////    struct Env {    //production
////        static let Domain = "https://app.myrepcard.com/"
////        static let StripPublishableKey = "pk_live_HEk97qMWzxVkIagdiFItGUxP"
////        static let GADMobileAdsAppID = "ca-app-pub-9133707516557572~5010711734"
////        static let GADInterstitialUnitID = "ca-app-pub-9133707516557572/6727118085"
////        static let GMSServicesAPIKey = "AIzaSyClVr1xMsLQJ73ynX8OADOkzUV6djO6wVI"
////        static let GMSPlacesClientAPIKey  = "AIzaSyClVr1xMsLQJ73ynX8OADOkzUV6djO6wVI"
////        static let CountryCode = "+1"
////    }
////
//    
//    static let BaseUrl = Env.Domain + "api/v1"
//    
//
//    static let defaultScreenRatio: Float = 320.0
//    static let contactUsEmail: String = "hello@myrepcard.com"
//    static let termsAndConditionUrl: String = BaseUrl + "/terms.jsp"
//    static let provicyPolicyUrl: String = BaseUrl + "/privacyPolicy.jsp"
//    static let DefaultDateFormat: String = "yyyy-MM-dd HH:mm:ss"
//    static let AppDefaultDateFormat: String = "dd-MM-yyyy HH:mm:ss"
//    static let versionSupportEndDateString: String = "2041-06-30"
//    static let numberOfEventsToShowTheAppRatingAlert: Int = 2
//    
//    
//
//    // MARK: Tokens
//    struct Tokens {
//        static let mixpanelToken: String = ""
//        static let flurryAppID: String = ""
//        static let googleAnalyticsAppID: String = ""
//    }
//    
//
//    struct NotificationNameIdentifiers {
//        static let contactAddedNotificationIdentifier = "CONTACT_ADDED"
//        static let recruitAddedNotificationIdentifier = "RECRUIT_ADDED"
//        static let recruitVideoLinkAddedNotificationIdentifier = "RECRUIT_VIDEO_LINK_ADDED"
//        static let prospectAddedNotificationIdentifier = "PROSPECT_ADDED"
//        static let customerAddedNotificationIdentifier = "CUSTOMER_ADDED"
//    }
//
//    struct NotificationNames {
//        static let contactAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.contactAddedNotificationIdentifier)
//        static let recruitAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.recruitAddedNotificationIdentifier)
//        static let prospectAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.prospectAddedNotificationIdentifier)
//        static let customerAddedNotificationName: Notification.Name = Notification.Name(rawValue: NotificationNameIdentifiers.customerAddedNotificationIdentifier)
//    }
//    
//    // MARK: ErrorMessages
//    struct ErrorMessages {
//
//        // Network Errors
//        static let networkDisconnected: String = "No internet connection available."
//        static let networkError: String = "Server is not responding."
//        static let loadingError: String = "Could not load page."
//        static let sessionExpireError: String = "Your session has expired."
//        static let responseParsingError: String = "Couldn't parse the response"
//        static let loginFailed: String = "Sorry, we can't log you in right now."
//        static let singupFailed: String = "An error occurred while sign up."
//        static let imageUploadFailed: String = "Image couldn't be uploaded."
//        static let imageUploadSuccess: String = "image uploaded successfully"
//        static let serverConnectionError: String = "Couldn't connect to server"
//
//        // Validation Errors
//        static let emptyPassword: String = "Please enter password."
//        static let emptyPhone: String = "Please enter phone number."
//
//        static let emptyConfimPassword: String = "Please enter confirm password."
//        static let passwordMismatch: String = "Password and Confirm Password do not match."
//        static let emptyFullName: String = "Please enter full name"
//        static let emptyFirstName: String = "Please enter first name"
//        static let emptyLastName: String = "Please enter last name"
//        static let emptyEmail: String = "Please enter an email"
//        static let emptyCompanyName: String = "Please enter company name"
//        static let emptyIndustryName: String = "Please select an industry"
//        
//        static let emptyName: String = "Please enter an name"
//
//        static let emptyProfileImage: String = "Please add profile picture"
//        static let invalidEmail: String = "Please enter a valid email."
//        static let invalidPhone: String = "Please enter a valid phone number."
//        static let emptyTitle: String = "Please enter a title."
//
//        static let invalidPassword: String = "Password must contain minimum 6 characters."
//        static let matchNewPassword: String = "New and current password must not be same."
//        static let descriptionOutOfRange: String = "Description can not be more than 100 characters long"
//        static let invalidUrl: String = "Invalid Url."
//        static let mismatchPassword: String = "New password and confirm password do not match."
//        static let emptyEventCollection: String = "No events to show"
//        static let subEmptyEventCollection: String = "No events to show"
//        static let emptySearchCollection: String = "No records found"
//        static let emptyNotificationCollection: String = "No notifications to show"
//        
//        static let INVALID_URL: String = "Invalid Url."
//        
//        static let ALREADY_LOGIN: String = "You already have a valid password."
//        
//        static let MISMATCH_PASSWORD: String = "New password and confirm password do not match."
//        static let EMPTY_PASSWORD: String = "Please enter password."
//        static let INVALID_PASSWORD: String = "Only alphanumaric letters and !@#$ are allowed"
//        static let SAME_PASSWORD: String = "New password and current password should not be same."
//
//
//    }
//
//    
//    // MARK: AlertTitles
//    struct AlertTitles {
//        static let repcardTitle = "RepCard"
//        static let errorTitle = repcardTitle
//        static let warningTitle = "Warning"
//        static let logoutTitle = "Logout"
//        static let successTitle = "Success"
//        static let confirmationTitle = "Please Confirm"
//        static let passwordTitle = "Enter Password"
//        static let deleteTitle = "Delete!"
//        static let flagTitle = "Flag!"
//    }
//    
//    // MARK: AlertTitleMessages
//    struct AlertTitleMessages {
//        static let confirmationTitleMessage = "Are you sure?"
//        static let emailUnsupported = "Can't send the email. Please configure an Email account in Settings or check your Internet connection."
//        static let smsUnsupported = "This device can't send a text message right now."
//        static let emailChangePasswordVerification = "You need to verify your password, in order to change your email address"
//        static let treeDeleteConfirmationMessage = "Please confirm that you want to delete this tree. Once a tree is deleted, all it's contents will be permanently removed"
//        static let treeLeaveConfirmationMessage = "Please confirm that you want to leave this tree. Once you leave you no longer will have any access or notifications from this tree and the chat group."
//        static let flagUserConfirmationMessage = "Please confirm if you want to flag this user. Once a user is flagged MemTree will review this request, and take neccessory actions."
//        static let branchDeleteConfirmationMessage = "Please confirm that you want to delete this branch. Once a branch is deleted, all it's contents will be permanently removed"
//        static let eventDeleteConfirmationMessage = "Please confirm that you want to delete this event. Once a event is deleted, all it's contents will be permanently removed"
//        static let twigDeleteConfirmationMessage = "Please confirm that you want to delete this Twig. Once a twig is deleted, all it's contents will be permanently removed"
//        static let leaveTreeMessage = "You have been remove from this tree."
//        static let invalidInput: String = "The input is invalid or not complete"
//        static let insallFBMessanger: String = "Please install facebook messenger for itunes."
//        static let trialExpiredMessage: String = "Your trial period has been expired, please purchase a subscription"
//        static let trialStartedMessage: String = "Your trial period has began! You can send 5 business card for free, after that its just $9.99(USD) per month for unlimited access."
//        static let trialRemainingMessage: String = "Your trial has 1 more free business card left. Please purchase a $9.99(USD) subscription for unlimited access!"
//        static let trialPurchasedMessage: String = "Thanks for purchasing subscription, now you can enjoy unlimitted business cards at $9.99(USD) per month."
//        static let trialCancelMessage: String = "We’d hate to see you go! Please confirm if you wanna proceed with canceling the subscription?"
//        static let somethingWrong: String = "Something went wrong."
//        static let invalidYoutubeUrl: String = "Please enter valid youtube url."
//        static let invalidURL: String = "The Url is invalid. Please add complete social URL, add http or https as required!"
//
//
//    }
//
//    struct ViewControllerIdentifiers {
//        static let loginViewController = "LoginViewController"
//    }
//    
//    struct MemTreeEvents {
//        static let NumberOfTreesCreated = "NumberOfTreesCreated"
//        static let NumberOfBranchesCreated = "NumberOfTreesCreated"
//    }
//    
//    struct ExperienceValue {
//        static let Rookie = "Rookie"
//        static let Vet = "Vet"
//    }
//    struct EventTye {
//        static let tree: Int = 1
//        static let branch: Int = 2
//    }
//
//    struct VideoType {
//        static let companyVideo: Int = 1
//        static let testimonialVideo: Int = 2
//    }
//    
//    struct HexColorCode {
//        static let appYellowColor = "#E2C710"
//        static let appGreenColor = "#2BCBB3"
//        static let appBlueColor = "#3A99D8"
//        static let appGrayColor = "#E5E5E5"
//        static let appBackgroundGrayColor = "#F9FAFC"
//    }
//    struct ViewControllerNibNames {
//        static let feedbackViewController = "FeedbackViewController"
//        static let termsAndConditionsViewController = "TermsViewController"
//        static let privacyPolicyViewController = "PrivacyViewController"
//    }
//
//    struct UtilityStrings {
//        static let termsAndConditionsString = "Terms & Conditions"
//        static let privacyPolicyString = "Privacy Policy"
//        static let contactUsString = "Contact Us"
//        static let agreementString = termsAndConditionsString + " and " + privacyPolicyString + "."
//    }
//
//    struct StoryboardIdentifiers {
//        static let createTreeEventPopupIdentifier = "CreateTreeEventPopup"
//    }
//
//    struct Keys {
//        static let Name = "Name"
//        static let date = "Date"
//        static let Manager = "Manager"
//        static let Status = "Status"
//        static let lastContacted = "Last contacted"
//        static let plus = "Plus"
//    }
//    // MARK: APIServices
//    struct APIServices {
//        
//        static let getVideoTestimonialsAPI = Constants.APIServices.apiURL("get-video-template-list")
//        static let notificationSettingAPI = Constants.APIServices.apiURL("notification/setting")
//        static let appFeedbackAPIEndpoint = Constants.APIServices.apiURL("feedback")
//        static let reportAbuseAPIEndpoint = Constants.APIServices.apiURL("feedback")
//        static let userAPIEndpoint = Constants.APIServices.apiURL("user/")
//        static let reviewAPIEndpoint = Constants.APIServices.apiURL("reviews/")
//        static let contactAPIEndpoint = userAPIEndpoint + "contact"
//        static let getRecrutingStatusAPI = Constants.APIServices.apiURL("user-recruit-status")
//        static let addRecruitAPI = Constants.APIServices.apiURL("recruit")
//        static let getRecruitAPI = Constants.APIServices.apiURL("recruit")
//        static let forgotPasswordAPI = userAPIEndpoint + "forgot-password"
//        static let emailVerification = userAPIEndpoint + "verify-email"
//        static let sendOTPNumberVerification = userAPIEndpoint + "verify-mobile-number"
//        static let phoneNumberVerification = userAPIEndpoint + "send-otp"
//        static let changePasswordAPI = userAPIEndpoint + "change-password"
//        static let resetPasswordAPI = userAPIEndpoint + "reset-password"
//        static let updateVideoURLAPI = userAPIEndpoint + "video-url"
//        static let validateTokenAPI = userAPIEndpoint + "validate-token"
//        static let textCampaginStartAPI = userAPIEndpoint + "text-campagin-start-time"
//        static let addEmailSchedular = "email-schedule"
//        static let deleteBusinessCardAPI = userAPIEndpoint + "%@/business-card-video"
//        
//        static let updateProfileAPI = userAPIEndpoint
//        static let convertToCustomerAPI = Constants.APIServices.apiURL("convert-to-customer")
//        static let logoutAPI = userAPIEndpoint + "logout"
//        static let searchUsersAPI = userAPIEndpoint + "search-users?page=%@"
//        static let sendBusinessCardAPI = Constants.APIServices.apiURL("send-business-card")
//        static let getAllIndustriesAPI = Constants.APIServices.apiURL("industries")
//        static let getProductListAPI = Constants.APIServices.apiURL("product/list")
//        static let placeIDBadgeAPI = Constants.APIServices.apiURL("product/order")
//        static let discountIDBadgeAPI = Constants.APIServices.apiURL("product/discount")
//        static let getCardsAPI = Constants.APIServices.apiURL("payment-cards")
//        static let addCardAPI = Constants.APIServices.apiURL("payment-cards")
//        static let startSubscriptionAPI = Constants.APIServices.apiURL("subscriptions/subscribe")
//        static let endSubscriptionAPI = Constants.APIServices.apiURL("subscriptions/cancel")
//        static let setCardAsDefaultAPI = Constants.APIServices.apiURL("payment-cards/set-default-card")
//        static let setRecruiterCardAPI = "/recruiter-profile"
//        static let testimonialAPI = "/testimonial/"
//        static let uploadImageAPI = "upload-image"
//        static let uploadVideoAPI = "upload-video"
//        static let uploadTestimonialVideoAPI = "upload-testimonial"
//        static let getOTPAPI = Constants.APIServices.apiURL("otp/generate")
//        static let verifyOTPAPI = Constants.APIServices.apiURL("otp/verify")
//        
//        // Login/Registration
//        static let sigupAPI = userAPIEndpoint + "register"
//        static let loginAPI = userAPIEndpoint + "login"
//        static let checkAccountAPI = userAPIEndpoint + "login-with-provider"
//        static let socialLogin = userAPIEndpoint + "social-login"
//        static let userProfile = userAPIEndpoint
//        static let termAndCondition = Constants.APIServices.apiURL("terms-and-conditions")
//        static let privacyPolicy = Constants.APIServices.apiURL("privacy")
//        
//        //customer
//        static let createCustomerAPI = userAPIEndpoint
//
//        
//        // Images
//        static let uploadImage = userAPIEndpoint + "upload-image"
//        static let uploadVideo = userAPIEndpoint + "upload-video"
//        // Notifications
//        static let notifications = userAPIEndpoint + "notifications?page=%@"
//        static let reminderNotificationDaysAPI = userAPIEndpoint + "recruit-notification-reminder-days"
//        
//        
//        static let clearNotificationsCount = userAPIEndpoint + "clear-notification-count"
//        static let markNotificationsReadAPI = userAPIEndpoint + "mark-as-read"
//        
//        //Campaign
//        static let createTextCampaigns = Constants.APIServices.apiURL("text-campaigns")
//        static let getTextCampaigns = Constants.APIServices.apiURL("text-campaigns")
//        static let deleteTextCampaigns = Constants.APIServices.apiURL("text-campaigns")
//        static let updateTextCampaignSetting = Constants.APIServices.apiURL("user/%d/settings")
//        //URL : api/v1/text-campaigns?type=1   (for filter on type)
//        //api/v1/text-campaigns?type=2&isPagination=1&search=with two mesg
//        //send isPagination = 1
//
//        static func apiURL(_ methodName: String) -> String {
//            return BaseUrl + "/" + methodName
//        }
//    }
//}
//
//
//enum MessageRepeatFequency: String, CaseIterable {
//    case None = ""
//    case Daily = "Daily"
//    case Weekly = "Weekly"
//    case Monthly = "Monthly"
//    
//    static let allValuesExceptNone = [Daily.rawValue, Weekly.rawValue, Monthly.rawValue]
//    
//    init?(id : Int) {
//        switch id {
//        case 0:
//            self = .None
//        case 1:
//            self = .Daily
//        case 2:
//            self = .Weekly
//        case 3:
//            self = .Monthly
//        default:
//            return nil
//        }
//    }
//}
//
//enum Fequency: String, CaseIterable {
//    case None = ""
//    case Days = "Day(s)"
//    case Weeks = "Week(s)"
//    case Month = "Month(s)"
//    case Year = "Year(s)"
//    
//    static let allValuesExceptNone = [Days.rawValue, Weeks.rawValue, Month.rawValue, Year.rawValue]
//    
//    init?(id : Int) {
//        switch id {
//        case 0:
//            self = .None
//        case 1:
//            self = .Days
//        case 2:
//            self = .Weeks
//        case 3:
//            self = .Month
//        case 4:
//            self = .Year
//        default:
//            return nil
//        }
//    }
//}
//
//enum RepeatFequency: String, CaseIterable {
//    case None = ""
//    case First = "First"
//    case Second = "Second"
//    case Third = "Third"
//    case Fourth = "Fourth"
//    case Fifth = "Fifth"
//    case Last = "Last"
//    
//    static let allValuesExceptNone = [First.rawValue, Second.rawValue, Third.rawValue, Fourth.rawValue, Fifth.rawValue, Last.rawValue]
//    
//    init?(id : Int) {
//        switch id {
//        case 0:
//            self = .None
//        case 1:
//            self = .First
//        case 2:
//            self = .Second
//        case 3:
//            self = .Third
//        case 4:
//            self = .Fourth
//        case 5:
//            self = .Fifth
//        case 6:
//            self = .Last
//        default:
//            return nil
//        }
//    }
//    
//    func getInNumber() -> Int {
//        switch self {
//            case .None:
//            return 0
//        case .First:
//            return 1
//        case .Second:
//            return 2
//        case .Third:
//            return 3
//        case .Fourth:
//            return 4
//        case .Fifth:
//            return 4
//        case .Last:
//            return 4
//            
//        }
//    }
//}
//
//enum WeekDayName: String, CaseIterable {
//    case None = ""
//    case Sunday = "Sunday"
//    case Monday = "Monday"
//    case Tuesday = "Tuesday"
//    case Wednesday = "Wednesday"
//    case Thursday = "Thursday"
//    case Friday = "Friday"
//    case Saturday = "Saturday"
//    
//    static let allValuesExceptNone = [Sunday.rawValue, Monday.rawValue, Tuesday.rawValue, Wednesday.rawValue, Thursday.rawValue, Friday.rawValue, Saturday.rawValue]
//    
//    init?(id : Int) {
//        switch id {
//        case 0:
//            self = .None
//        case 1:
//            self = .Sunday
//        case 2:
//            self = .Monday
//        case 3:
//            self = .Tuesday
//        case 4:
//            self = .Wednesday
//        case 5:
//            self = .Thursday
//        case 6:
//            self = .Friday
//        case 7:
//            self = .Saturday
//        default:
//            return nil
//        }
//    }
//    
//    func getDayInNumber() -> Int {
//        switch self {
//        case .None:
//            return 0
//        case .Sunday:
//            return 1
//        case .Monday:
//            return 2
//        case .Tuesday:
//            return 3
//        case .Wednesday:
//            return 4
//        case .Thursday:
//            return 5
//        case .Friday:
//            return 6
//        case .Saturday:
//            return 7
//        }
//    }
//}
//
////     "deliveryMethod": 1, </'Text(1), Email(2), Both(3)'/>
//
//enum MessageDeliveryMethod: String, CaseIterable {
//    case None = ""
//    case Text = "Text"
//    case Email = "Email"
//    case Both = "Both"
//    
//    static let allValuesExceptNone = [Text.rawValue, Email.rawValue, Both.rawValue]
//    
//    init?(id : Int) {
//        switch id {
//        case 0:
//            self = .None
//        case 1:
//            self = .Text
//        case 2:
//            self = .Email
//        case 3:
//            self = .Both
//        default:
//            return nil
//        }
//    }
//    
//    func getInNumber() -> Int {
//        switch self {
//        case .None:
//            return 0
//        case .Text:
//            return 1
//        case .Email:
//            return 2
//        case .Both:
//            return 3
//        }
//    }
//}
//
//enum CampaningEndDateType {
//    case None
//    case Never
//    case On
//    case After
//    
//    init?(id : Int) {
//        switch id {
//        case 0:
//            self = .None
//        case 1:
//            self = .Never
//        case 2:
//            self = .On
//        case 3:
//            self = .After
//        default:
//            self = .None
//        }
//    }
//    
//    func getInString() -> String {
//        switch self {
//        case .None:
//            return ""
//        case .Never:
//            return "Never"
//        case .On:
//            return "On"
//        case .After:
//            return "After"
//        }
//    }
//    
//    func getInNumber() -> Int {
//        switch self {
//        case .None:
//            return 0
//        case .Never:
//            return 1
//        case .On:
//            return 2
//        case .After:
//            return 3
//        }
//    }
//    
//}
//
//enum CampaningType {
//    case None
//    case Single
//    case Multiple
//    
//    func getInNumber() -> Int {
//        switch self {
//        case .None:
//            return 0
//        case .Single:
//            return 1
//        case .Multiple:
//            return 2
//        }
//    }
//}
//
//enum CampaningStatus: String, CaseIterable {
//    case None = ""
//    case Draft = "draft"
//    case Planned = "planned"
//}
//
//enum MonthlyRepeatType: String, CaseIterable {
//    case None = ""
//    case On = "on"
//    case Day = "day"
//}

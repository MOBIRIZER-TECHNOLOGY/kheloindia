//
//  NewVenueCell.swift
//  KheloIndia
//
//  Created by Narender Kumar on 12/14/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

protocol NewVenueCellDelegate: class {
    func didVenueTapped(venue: Venue?)
}

class NewVenueCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var subTitleLbl: UILabel!
    var locationDelagate: NewVenueCellDelegate?
    var venue: Venue? = nil

    override func awakeFromNib() {
        super.awakeFromNib()
                
        bgView.backgroundColor = UIColor.white
        bgView.addShadow() //use from any view
    }
 
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setVenueData(_ venue: Venue) {
        self.venue = venue
        titleLbl.text = venue.VenueName
        subTitleLbl.text = venue.VenueAddress
    }
    
    @IBAction func newVenueAction(_ sender: UIButton) {
        locationDelagate?.didVenueTapped(venue: venue)
    }
    
}




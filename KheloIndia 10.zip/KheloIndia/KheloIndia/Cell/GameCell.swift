//
//  Cell.swift
//  camera
//
//  Created by Rishi Kumar on 15/12/19.
//  Copyright © 2019 imaginaryCloud. All rights reserved.
//

import UIKit

class GameCell: UICollectionViewCell {
    
    @IBOutlet weak var gameName: UILabel!
    @IBOutlet weak var imgIcon: UIImageView!
    
}

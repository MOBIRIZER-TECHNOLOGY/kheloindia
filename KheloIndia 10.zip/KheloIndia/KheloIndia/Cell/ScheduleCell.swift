//
//  ScheduleCell.swift
//  KheloIndia
//
//  Created by pawan singh on 16/12/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class ScheduleCell: UITableViewCell {
        
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var gameTypeLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!

        private var schedule: Schedule? = nil

        override func awakeFromNib() {
            super.awakeFromNib()
            self.roundCorners(view: gameTypeLabel, corners: [ .topLeft], radius: 10.0)

            // Initialization code
        }

    //MARK:- Corner Radius of only two side of UIViews
    func roundCorners(view :UIView, corners: UIRectCorner, radius: CGFloat){
            let path = UIBezierPath(roundedRect: view.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            let mask = CAShapeLayer()
            mask.path = path.cgPath
            view.layer.mask = mask
    }
        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)

            // Configure the view for the selected state
        }

        
        func setData(_ schedule: Schedule) {
            self.titleLabel.text = schedule.eventName
            self.gameTypeLabel.text = schedule.sportsName
            self.locationLabel.text = schedule.venueName
            self.dateLabel.text = schedule.eventDate

            if (schedule.result != nil) && schedule.result!.length > 0 {
                self.resultLabel.text =  schedule.result!
            }
            else {
                self.resultLabel.text =  schedule.eventTime!  //"Start At : - " +
            }
 
        }
    }

//
//  MenuCell.swift
//  KheloIndia
//
//  Created by Sudhir Kumar on 12/11/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

class MenuCell: UITableViewCell {

    // IBOutlets
    @IBOutlet weak var menuItemLabel: UILabel!
    
    // Class iVar
    class var identifier:String {
        return String(describing: self)
    }
    
    class var nib:UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    
    //MARK: - Initilizer
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    //MARK: - Custom Method
    func configureCell(_ title:String?) {
        menuItemLabel.text = title
    }
    
}

//
//  FeedbackCell.swift
//  KheloIndia
//
//  Created by Narender Kumar on 12/15/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

//typealias feedbackTuple = (name: String, value: Int)
protocol FeedbackCellDelegate: class {
    func didFeedbackTapped(feedback: (name: String, value: Int))
}

class FeedbackCell: UITableViewCell {
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var firstBtn: UIButton!
    @IBOutlet weak var secBtn: UIButton!
    @IBOutlet weak var thrdBtn: UIButton!
    var delegate:FeedbackCellDelegate? = nil
    var feedback: (name: String, value: Int)? = nil
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setData(_ tpl: (name: String, value: Int)) {
        
        self.feedback = tpl
        nameLbl.text = tpl.name
        
        firstBtn.setImage(UIImage(named: "happy_1_us"), for: .normal)
        secBtn.setImage(UIImage(named: "happy_2_us"), for: .normal)
        thrdBtn.setImage(UIImage(named: "happy_3_us"), for: .normal)
        
        if tpl.value == 1 {
            firstBtn.setImage(UIImage(named: "happy_1_s"), for: .normal)
            self.feedback?.value = 1
        } else if tpl.value == 2 {
            secBtn.setImage(UIImage(named: "happy_2_s"), for: .normal)
            self.feedback?.value = 2
        } else if tpl.value == 3 {
            thrdBtn.setImage(UIImage(named: "happy_3_s"), for: .normal)
            self.feedback?.value = 3
        }
    }
    
    private func setBtn(_ sender: UIButton) {
        firstBtn.setImage(UIImage(named: "happy_1_us"), for: .normal)
        secBtn.setImage(UIImage(named: "happy_2_us"), for: .normal)
        thrdBtn.setImage(UIImage(named: "happy_3_us"), for: .normal)
        
        if sender.tag == 11 {
            firstBtn.setImage(UIImage(named: "happy_1_s"), for: .normal)
            self.feedback?.value = 1
        } else if sender.tag == 12 {
            secBtn.setImage(UIImage(named: "happy_2_s"), for: .normal)
            self.feedback?.value = 2
        } else if sender.tag == 13 {
            thrdBtn.setImage(UIImage(named: "happy_3_s"), for: .normal)
            self.feedback?.value = 3
        }
    }
    
    @IBAction func btnAction(_ sender: UIButton) {
        // happy_1_us     happy_1_s
        // happy_2_us     happy_2_s
        // happy_3_us     happy_3_s
        
        //Breakfast, Lunch, Snacks, Dinner ----- Transportation, Hotel
        self.setBtn(sender)
        delegate?.didFeedbackTapped(feedback: self.feedback!)

        if let _ = self.feedback {
        }
        
    }
    
    
}

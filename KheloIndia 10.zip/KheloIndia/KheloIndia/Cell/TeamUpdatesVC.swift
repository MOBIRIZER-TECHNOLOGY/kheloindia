//
//  TeamUpdatesVC.swift
//  camera
//
//  Created by Rishi Kumar on 15/12/19.
//  Copyright © 2019 imaginaryCloud. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class TeamUpdatesVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: UICollectionView!
     let images = ["archery","athletics","badminton" , "basketball" , "boxing", "cycling" ,"football" ,"gynastics" , "hockey" , "judo" , "kabaddi" ,"khokho" , "lawnball" , "shooting", "swimming" , "tabletennis" , "tennis" , "volleyball" , "weightLifting", "wrestling"]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        //self.collectionView!.register(GameCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        // Do any additional setup after loading the view.
    }
    
    
    
//     func numberOfSections(in collectionView: UICollectionView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 0
//    }
    
    
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return images.count
    }
    
     func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! GameCell
        // Configure the cell
        cell.imgIcon.image = UIImage.init(named:images[indexPath.row] )
        cell.gameName.text = images[indexPath.row].capitalized;
        cell.layer.borderColor = UIColor.gray.cgColor
        cell.layer.borderWidth = 0.5
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (self.view.frame.size.width ) / 4 //some width
        let height = width + 10  //ratio
        return CGSize(width: width, height: height)
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

class game {
    var imageName:String?
    var title:String?
}


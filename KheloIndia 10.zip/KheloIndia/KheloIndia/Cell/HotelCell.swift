//
//  HotelCell.swift
//  KheloIndia
//
//  Created by Narender Kumar on 12/14/19.
//  Copyright © 2019 Mobirizer. All rights reserved.
//

import UIKit

protocol HotelCellDelegate: class {
    func didTappedCommon(isNavigation:Bool, isCall: Bool, hotel: Hotel?)
}

 
class HotelCell: UITableViewCell {

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var subTitleLbl: UILabel!
    var delagate: HotelCellDelegate? = nil
    var hotel: Hotel? = nil
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        bgView.backgroundColor = UIColor.white
        bgView.addShadow() //use from any view

    }
 
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func setHotelData(_ hotel: Hotel) {
        self.hotel = hotel
        titleLbl.text = hotel.HotelName
        subTitleLbl.text = hotel.HotelAddress
    }
    
    @IBAction func navigationAction(_ sender: UIButton) {
        delagate?.didTappedCommon(isNavigation: true, isCall: false, hotel: self.hotel)
    }
    
    @IBAction func callAction(_ sender: UIButton) {
        delagate?.didTappedCommon(isNavigation: false, isCall: true, hotel: self.hotel)
    }
    
}
